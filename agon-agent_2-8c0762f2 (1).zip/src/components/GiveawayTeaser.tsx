import { Link } from 'react-router-dom';
import { Trophy, ArrowLeft, Flame } from 'lucide-react';
import { useEffect, useState } from 'react';

function useCountdown() {
  const [end] = useState(() => {
    const stored = localStorage.getItem('muthmir.giveaway.end');
    if (stored) return parseInt(stored, 10);
    const future = Date.now() + 10 * 24 * 60 * 60 * 1000;
    localStorage.setItem('muthmir.giveaway.end', String(future));
    return future;
  });
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, []);
  let diff = Math.max(0, end - now);
  const days = Math.floor(diff / 86400000); diff -= days * 86400000;
  const hours = Math.floor(diff / 3600000); diff -= hours * 3600000;
  const minutes = Math.floor(diff / 60000);
  return { days, hours, minutes };
}

/**
 * Compact giveaway teaser shown inside the user dashboard to encourage deposits.
 * Clicking takes the user directly to the deposit page.
 */
export default function GiveawayTeaser() {
  const { days, hours, minutes } = useCountdown();
  return (
    <Link
      to="/app/wallet"
      className="group relative block rounded-2xl overflow-hidden border border-[color:var(--color-gold)]/35 bg-gradient-to-l from-[#1a0f2e] via-[#0B1A2F] to-[#2a1810] active:scale-[0.99] transition hover:border-[color:var(--color-gold)]/60 hover:shadow-[0_10px_40px_-10px_rgba(245,194,75,0.5)]"
    >
      {/* Glows */}
      <div className="absolute -top-16 -right-10 w-48 h-48 rounded-full bg-[#F5C24B]/25 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-16 -left-10 w-48 h-48 rounded-full bg-rose-500/15 blur-3xl pointer-events-none" />

      {/* Sparkles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(6)].map((_, i) => (
          <span
            key={i}
            className="absolute w-1 h-1 rounded-full bg-[color:var(--color-gold)]"
            style={{
              top: `${10 + ((i * 31) % 80)}%`,
              left: `${10 + ((i * 53) % 80)}%`,
              animation: `sparkle ${2 + (i % 3)}s ease-in-out ${i * 0.4}s infinite`,
            }}
          />
        ))}
      </div>

      <div className="relative flex items-center gap-3 md:gap-5 p-4 md:p-5">
        {/* iPhone thumbnail */}
        <div className="relative shrink-0 w-16 h-16 md:w-20 md:h-20 rounded-xl overflow-hidden bg-black/40 border border-[color:var(--color-gold)]/30">
          <img src="/images/iphone-giveaway.png" alt="iPhone 17 Pro Max" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-500/20 border border-rose-400/40 text-rose-200 text-[10px] font-bold">
              <Flame size={10} className="animate-pulse" /> جديد
            </span>
            <span className="text-[10px] md:text-xs text-[color:var(--color-ink-muted)]">
              ينتهي خلال <span className="num font-bold text-[color:var(--color-gold)]">{days}ي {hours}س {minutes}د</span>
            </span>
          </div>
          <div className="font-bold text-base md:text-lg leading-tight">
            اربح <span className="text-gold-gradient">iPhone 17 Pro Max</span>
          </div>
          <div className="text-[11px] md:text-xs text-[color:var(--color-ink-muted)] mt-0.5 truncate">
            أكثر مستخدم يودع هذا الشهر يفوز بالهاتف · كل $10 = دخول سحب
          </div>
        </div>

        {/* CTA arrow */}
        <div className="shrink-0 flex items-center gap-2">
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl bg-gradient-to-l from-[#F5C24B] to-[#B8860B] text-[#07111F] font-extrabold text-xs md:text-sm shadow-lg group-hover:brightness-110">
            <Trophy size={14} /> أودع الآن
          </div>
          <div className="sm:hidden w-9 h-9 rounded-xl bg-gradient-to-l from-[#F5C24B] to-[#B8860B] text-[#07111F] flex items-center justify-center shadow-lg">
            <ArrowLeft size={16} />
          </div>
        </div>
      </div>

      {/* Gold ribbon */}
      <div className="h-1 bg-gradient-to-l from-[#F5C24B] via-[#E0A93A] to-[#B8860B]" />
    </Link>
  );
}
