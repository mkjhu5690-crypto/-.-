export default function Logo({ size = 36 }: { size?: number }) {
  return (
    <div className="flex items-center gap-2.5">
      <svg width={size} height={size} viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="lg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#F5E29B" />
            <stop offset="0.5" stopColor="#F5C24B" />
            <stop offset="1" stopColor="#B8860B" />
          </linearGradient>
        </defs>
        <rect width="64" height="64" rx="14" fill="#0B1A2F" stroke="#1E3A5F" />
        <path d="M14 48 L14 20 L22 30 L32 16 L42 30 L50 20 L50 48 Z" fill="url(#lg)" />
        <circle cx="32" cy="40" r="3" fill="#0B1A2F" />
      </svg>
      <div className="flex flex-col leading-none">
        <span className="font-display text-xl font-bold text-gold-gradient">مُثمِر</span>
        <span className="text-[10px] text-[color:var(--color-ink-muted)] tracking-widest">MUTHMIR · INVEST</span>
      </div>
    </div>
  );
}
