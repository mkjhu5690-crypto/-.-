import { useEffect, useState } from 'react';
import { Lock, Clock, Unlock, CalendarCheck } from 'lucide-react';
import { getWithdrawLockStatus, formatDateAr, type User, WITHDRAW_LOCK_DAYS } from '../lib/db';

export default function WithdrawCountdown({ user, compact = false }: { user: User; compact?: boolean }) {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const status = getWithdrawLockStatus(user, now);

  if (!status.locked) {
    // Unlocked
    if (compact) {
      return (
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[11px]">
          <Unlock size={11} /> السحب متاح
        </div>
      );
    }
    return (
      <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-200 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center shrink-0">
          <Unlock size={20} />
        </div>
        <div>
          <div className="font-bold text-sm">السحب متاح الآن</div>
          <div className="text-xs opacity-80">اكتملت فترة القفل - يمكنك سحب أرباحك متى شئت</div>
        </div>
      </div>
    );
  }

  // Locked — compact badge for inline use
  if (compact) {
    return (
      <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[11px]">
        <Lock size={11} /> متبقي {status.daysLeft} يوم
      </div>
    );
  }

  return (
    <div className="relative rounded-2xl overflow-hidden">
      {/* Gradient border */}
      <div className="relative rounded-2xl p-[1.5px] bg-gradient-to-br from-amber-400/50 via-[#F5C24B]/40 to-amber-700/40">
        <div className="rounded-[15px] bg-[color:var(--color-bg-2)] p-5">
          {/* Header */}
          <div className="flex items-start gap-3 mb-4">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-400 to-amber-700 flex items-center justify-center text-[#07111F] shrink-0">
              <Lock size={20} />
            </div>
            <div className="flex-1">
              <div className="font-bold text-[color:var(--color-gold)]">السحب مقفل مؤقتاً</div>
              <div className="text-xs text-[color:var(--color-ink-muted)] mt-0.5">
                يُفتح السحب بعد {WITHDRAW_LOCK_DAYS} يوماً من إنشاء الحساب (شهر + أسبوع)
              </div>
            </div>
          </div>

          {/* Countdown boxes */}
          <div className="grid grid-cols-4 gap-2 mb-4">
            <TimeBox value={status.daysLeft} label="يوم" />
            <TimeBox value={status.hoursLeft} label="ساعة" />
            <TimeBox value={status.minutesLeft} label="دقيقة" />
            <TimeBox value={status.secondsLeft} label="ثانية" pulse />
          </div>

          {/* Progress bar */}
          <div className="mb-3">
            <div className="flex justify-between text-[11px] text-[color:var(--color-ink-muted)] mb-1.5">
              <span className="flex items-center gap-1"><Clock size={11} /> التقدم</span>
              <span className="num font-bold text-[color:var(--color-gold)]">{status.progressPercent.toFixed(1)}%</span>
            </div>
            <div className="h-2.5 rounded-full bg-[color:var(--color-surface-2)] overflow-hidden relative">
              <div
                className="h-full bg-gradient-to-l from-[#F5E29B] via-[#F5C24B] to-[#B8860B] transition-all duration-1000 relative overflow-hidden"
                style={{ width: `${status.progressPercent}%` }}
              >
                <div className="absolute inset-0 shine" />
              </div>
            </div>
          </div>

          {/* Unlock date */}
          <div className="flex items-center gap-2 text-xs text-[color:var(--color-ink-muted)] pt-2 border-t border-[color:var(--color-border)]">
            <CalendarCheck size={14} className="text-[color:var(--color-gold)]" />
            <span>يُفتح السحب في: <span className="text-[color:var(--color-ink)] font-bold">{formatDateAr(status.unlockAt)}</span></span>
          </div>
        </div>
      </div>
    </div>
  );
}

function TimeBox({ value, label, pulse }: { value: number; label: string; pulse?: boolean }) {
  const display = value.toString().padStart(2, '0');
  return (
    <div className={`p-2 md:p-3 rounded-xl bg-[color:var(--color-bg)]/70 border border-[color:var(--color-gold)]/20 text-center ${pulse ? 'animate-[pulseGlow_2s_ease-in-out_infinite]' : ''}`}>
      <div className="num text-2xl md:text-3xl font-extrabold text-gold-gradient leading-none">{display}</div>
      <div className="text-[10px] md:text-[11px] text-[color:var(--color-ink-muted)] mt-1.5">{label}</div>
    </div>
  );
}
