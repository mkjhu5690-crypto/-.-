import { Check, Sparkles } from 'lucide-react';
import type { Plan } from '../lib/db';

const tierStyles: Record<string, { ring: string; badge: string; title: string; icon: string }> = {
  bronze: {
    ring: 'from-amber-700/60 to-orange-900/40',
    badge: 'bg-gradient-to-br from-amber-600 to-amber-900 text-amber-100',
    title: 'text-amber-300',
    icon: '🥉',
  },
  silver: {
    ring: 'from-slate-300/60 to-slate-600/30',
    badge: 'bg-gradient-to-br from-slate-200 to-slate-500 text-slate-900',
    title: 'text-slate-200',
    icon: '🥈',
  },
  gold: {
    ring: 'from-[#F5C24B]/70 to-[#B8860B]/40',
    badge: 'bg-gradient-to-br from-[#F5E29B] to-[#B8860B] text-[#3a2500]',
    title: 'text-[color:var(--color-gold)]',
    icon: '🥇',
  },
  diamond: {
    ring: 'from-cyan-300/70 to-indigo-600/40',
    badge: 'bg-gradient-to-br from-cyan-200 to-indigo-500 text-indigo-950',
    title: 'text-cyan-200',
    icon: '💎',
  },
};

export default function PlanCard({
  plan,
  onSelect,
  disabled,
  featured,
  actionLabel = 'اشتراك الآن',
}: {
  plan: Plan;
  onSelect?: () => void;
  disabled?: boolean;
  featured?: boolean;
  actionLabel?: string;
}) {
  const s = tierStyles[plan.id];
  const daily = +(plan.price * (plan.dailyPercent / 100)).toFixed(2);
  const monthly = +(daily * plan.durationDays).toFixed(2);

  return (
    <div className={`relative rounded-3xl p-[1.5px] bg-gradient-to-br ${s.ring} ${featured ? 'scale-[1.02] md:scale-105' : ''}`}>
      {featured && (
        <div className="absolute -top-3 right-6 z-10">
          <div className="flex items-center gap-1 px-3 py-1 rounded-full btn-gold text-[11px]">
            <Sparkles size={12} /> الأكثر طلباً
          </div>
        </div>
      )}
      <div className="rounded-[22px] bg-[color:var(--color-bg-2)] p-6 h-full flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <div className={`text-2xl ${s.badge} w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg`}>{s.icon}</div>
          <div className="text-left">
            <div className={`font-display text-xl font-bold ${s.title}`}>{plan.nameAr}</div>
            <div className="text-[11px] text-[color:var(--color-ink-muted)]">{plan.durationDays} يوماً</div>
          </div>
        </div>

        <div className="mt-2">
          <div className="flex items-baseline gap-1">
            <span className="num text-4xl font-extrabold">${plan.price}</span>
            <span className="text-[color:var(--color-ink-muted)] text-sm">/ اشتراك</span>
          </div>
          <div className="mt-2 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs">
            <span className="num font-bold">{plan.dailyPercent}%</span>
            <span>عائد يومي</span>
          </div>
        </div>

        <div className="my-5 divider-gold" />

        <ul className="space-y-2.5 mb-6 flex-1">
          <li className="flex items-center gap-2 text-sm">
            <Check size={16} className="text-emerald-400 shrink-0" />
            <span>عائد يومي <span className="num font-bold text-[color:var(--color-gold)]">${daily}</span></span>
          </li>
          <li className="flex items-center gap-2 text-sm">
            <Check size={16} className="text-emerald-400 shrink-0" />
            <span>عائد تراكمي <span className="num font-bold">${monthly}</span></span>
          </li>
          {plan.perks.map(p => (
            <li key={p} className="flex items-center gap-2 text-sm text-[color:var(--color-ink-muted)]">
              <Check size={16} className="text-emerald-400 shrink-0" />
              <span>{p}</span>
            </li>
          ))}
        </ul>

        {onSelect && (
          <button
            onClick={onSelect}
            disabled={disabled}
            className={`w-full py-3 rounded-xl text-sm ${featured || plan.id === 'gold' ? 'btn-gold' : 'btn-ghost hover:border-[color:var(--color-gold)]/40'}`}
          >
            {actionLabel}
          </button>
        )}
      </div>
    </div>
  );
}
