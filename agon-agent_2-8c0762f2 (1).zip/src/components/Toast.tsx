import { useEffect, useState } from 'react';
import { CheckCircle2, XCircle, Info } from 'lucide-react';

type ToastKind = 'success' | 'error' | 'info';
interface ToastItem { id: number; kind: ToastKind; text: string }

let push: (t: Omit<ToastItem, 'id'>) => void = () => {};
export function toast(t: Omit<ToastItem, 'id'>) { push(t); }

export default function Toaster() {
  const [items, setItems] = useState<ToastItem[]>([]);
  useEffect(() => {
    push = (t) => {
      const id = Date.now() + Math.random();
      setItems(prev => [...prev, { ...t, id }]);
      setTimeout(() => setItems(prev => prev.filter(x => x.id !== id)), 3500);
    };
  }, []);
  const color = (k: ToastKind) =>
    k === 'success' ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-200'
    : k === 'error' ? 'border-rose-500/40 bg-rose-500/10 text-rose-200'
    : 'border-sky-500/40 bg-sky-500/10 text-sky-200';
  const Icon = (k: ToastKind) => k === 'success' ? CheckCircle2 : k === 'error' ? XCircle : Info;
  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[100] flex flex-col gap-2 w-[90%] max-w-md">
      {items.map(t => {
        const I = Icon(t.kind);
        return (
          <div key={t.id} className={`flex items-center gap-3 px-4 py-3 rounded-xl border backdrop-blur ${color(t.kind)} shadow-xl`}>
            <I size={18} />
            <span className="text-sm font-medium">{t.text}</span>
          </div>
        );
      })}
    </div>
  );
}
