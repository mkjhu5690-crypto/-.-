import { NavLink, useNavigate, Link } from 'react-router-dom';
import { LayoutDashboard, Wallet as WalletIcon, Layers, Receipt, LogOut, Gem, Menu, X } from 'lucide-react';
import Logo from './Logo';
import { useAuth } from '../lib/auth';
import { formatMoney } from '../lib/db';
import { useEffect, useState } from 'react';

const nav = [
  { to: '/app', icon: LayoutDashboard, label: 'الرئيسية', short: 'الرئيسية', end: true },
  { to: '/app/wallet', icon: WalletIcon, label: 'المحفظة', short: 'محفظة' },
  { to: '/app/plans', icon: Gem, label: 'خطط الاستثمار', short: 'خطط' },
  { to: '/app/subscriptions', icon: Layers, label: 'اشتراكاتي', short: 'اشتراكات' },
  { to: '/app/history', icon: Receipt, label: 'سجل المعاملات', short: 'السجل' },
];

export default function AppShell({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  // Lock scroll when mobile sidebar is open
  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [open]);

  const doLogout = () => { logout(); navigate('/'); };

  return (
    <div className="min-h-screen flex">
      {/* Desktop sidebar / Mobile drawer */}
      <aside
        className={`fixed lg:static inset-y-0 right-0 z-50 w-[85vw] max-w-xs lg:w-72 bg-[color:var(--color-bg-2)]/98 lg:bg-[color:var(--color-bg-2)]/95 backdrop-blur-xl border-l border-[color:var(--color-border)] transform transition-transform duration-300 ease-out ${open ? 'translate-x-0 shadow-2xl' : 'translate-x-full'} lg:translate-x-0 flex flex-col safe-top safe-bottom`}
      >
        <div className="p-5 lg:p-6 border-b border-[color:var(--color-border)] flex items-center justify-between">
          <Link to="/app" onClick={() => setOpen(false)}><Logo /></Link>
          <button
            className="lg:hidden w-10 h-10 rounded-xl bg-[color:var(--color-surface)] text-[color:var(--color-ink-muted)] flex items-center justify-center active:scale-95 transition"
            onClick={() => setOpen(false)}
            aria-label="إغلاق"
          >
            <X size={20} />
          </button>
        </div>

        {user && (
          <div className="mx-4 lg:mx-5 mt-4 lg:mt-5 p-4 rounded-2xl card card-glow">
            <div className="text-xs text-[color:var(--color-ink-muted)] mb-1">الرصيد المتاح</div>
            <div className="num text-2xl font-bold text-gold-gradient">{formatMoney(user.balance)}</div>
            <div className="mt-3 text-xs text-[color:var(--color-ink-muted)] truncate">مرحباً، <span className="text-[color:var(--color-ink)]">{user.name}</span></div>
          </div>
        )}

        <nav className="flex-1 p-3 lg:p-4 space-y-1 overflow-y-auto">
          {nav.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              onClick={() => setOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-sm active:scale-[0.98] ${
                  isActive
                    ? 'bg-gradient-to-l from-[#F5C24B]/20 to-transparent text-[color:var(--color-gold)] border border-[color:var(--color-gold)]/25'
                    : 'text-[color:var(--color-ink-muted)] hover:bg-[color:var(--color-surface)] hover:text-[color:var(--color-ink)]'
                }`
              }
            >
              <item.icon size={18} />
              <span className="font-semibold">{item.label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="p-3 lg:p-4 border-t border-[color:var(--color-border)]">
          <button onClick={doLogout} className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl btn-ghost text-sm active:scale-[0.98]">
            <LogOut size={18} /> تسجيل الخروج
          </button>
        </div>
      </aside>

      {/* Mobile backdrop */}
      {open && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden animate-[fadeIn_0.2s_ease-out]"
          onClick={() => setOpen(false)}
        />
      )}

      {/* Main */}
      <main className="flex-1 min-w-0 w-full">
        {/* Mobile header */}
        <header className="lg:hidden sticky top-0 z-30 bg-[color:var(--color-bg-2)]/95 backdrop-blur-xl border-b border-[color:var(--color-border)] px-4 py-3 flex items-center justify-between safe-top">
          <Logo size={28} />
          <div className="flex items-center gap-2">
            {user && (
              <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[color:var(--color-surface)]/60 border border-[color:var(--color-border)]">
                <div className="w-1.5 h-1.5 rounded-full bg-[color:var(--color-gold)]" />
                <span className="num text-xs font-bold text-[color:var(--color-gold)]">{formatMoney(user.balance)}</span>
              </div>
            )}
            <button
              onClick={() => setOpen(true)}
              className="w-10 h-10 rounded-xl bg-[color:var(--color-surface)] border border-[color:var(--color-border)] flex items-center justify-center active:scale-95 transition"
              aria-label="فتح القائمة"
            >
              <Menu size={20} />
            </button>
          </div>
        </header>

        <div className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto pb-24 lg:pb-8">{children}</div>

        {/* Mobile bottom nav */}
        <nav className="lg:hidden fixed bottom-0 inset-x-0 z-30 bg-[color:var(--color-bg-2)]/95 backdrop-blur-xl border-t border-[color:var(--color-border)] safe-bottom">
          <div className="flex items-center justify-around px-1 py-1.5">
            {nav.map(item => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  `flex flex-col items-center gap-0.5 px-2 py-2 rounded-lg min-w-[56px] transition-all active:scale-95 ${
                    isActive
                      ? 'text-[color:var(--color-gold)]'
                      : 'text-[color:var(--color-ink-muted)]'
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    <div className={`transition-transform ${isActive ? 'scale-110' : ''}`}>
                      <item.icon size={20} />
                    </div>
                    <span className="text-[10px] font-bold">{item.short}</span>
                    {isActive && <div className="absolute bottom-1 w-6 h-0.5 rounded-full bg-[color:var(--color-gold)]" />}
                  </>
                )}
              </NavLink>
            ))}
          </div>
        </nav>
      </main>
    </div>
  );
}
