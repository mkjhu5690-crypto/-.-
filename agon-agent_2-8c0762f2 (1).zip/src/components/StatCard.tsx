import type { LucideIcon } from 'lucide-react';

export default function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  tone = 'gold',
}: {
  icon: LucideIcon;
  label: string;
  value: string;
  sub?: string;
  tone?: 'gold' | 'emerald' | 'rose' | 'sky';
}) {
  const tones: Record<string, string> = {
    gold: 'from-[#F5C24B]/25 to-[#B8860B]/5 text-[color:var(--color-gold)]',
    emerald: 'from-emerald-400/25 to-emerald-800/5 text-emerald-300',
    rose: 'from-rose-400/25 to-rose-800/5 text-rose-300',
    sky: 'from-sky-400/25 to-sky-800/5 text-sky-300',
  };
  return (
    <div className="card p-4 md:p-5 relative overflow-hidden">
      <div className={`absolute -top-10 -left-10 w-40 h-40 rounded-full blur-3xl bg-gradient-to-br ${tones[tone]} opacity-60 pointer-events-none`} />
      <div className="flex items-start justify-between relative gap-2">
        <div className="min-w-0 flex-1">
          <div className="text-[11px] md:text-xs text-[color:var(--color-ink-muted)] mb-1.5 md:mb-2 truncate">{label}</div>
          <div className="num text-xl sm:text-2xl md:text-3xl font-extrabold tracking-tight truncate">{value}</div>
          {sub && <div className="text-[10px] md:text-xs text-[color:var(--color-ink-muted)] mt-1.5 md:mt-2 truncate">{sub}</div>}
        </div>
        <div className={`w-8 h-8 md:w-10 md:h-10 shrink-0 rounded-lg md:rounded-xl flex items-center justify-center bg-gradient-to-br ${tones[tone]} border border-white/5`}>
          <Icon size={18} />
        </div>
      </div>
    </div>
  );
}
