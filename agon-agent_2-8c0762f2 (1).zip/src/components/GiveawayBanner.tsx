import { Link } from 'react-router-dom';
import { Trophy, Gift, Sparkles, ArrowLeft, Flame, Crown, Zap } from 'lucide-react';
import { useEffect, useState } from 'react';

// A countdown ending ~10 days from now — resets gently if user returns later.
function useCountdown() {
  const [end] = useState(() => {
    const stored = localStorage.getItem('muthmir.giveaway.end');
    if (stored) return parseInt(stored, 10);
    const future = Date.now() + 10 * 24 * 60 * 60 * 1000;
    localStorage.setItem('muthmir.giveaway.end', String(future));
    return future;
  });
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  let diff = Math.max(0, end - now);
  const days = Math.floor(diff / 86400000); diff -= days * 86400000;
  const hours = Math.floor(diff / 3600000); diff -= hours * 3600000;
  const minutes = Math.floor(diff / 60000); diff -= minutes * 60000;
  const seconds = Math.floor(diff / 1000);
  return { days, hours, minutes, seconds };
}

export default function GiveawayBanner() {
  const { days, hours, minutes, seconds } = useCountdown();
  const pad = (n: number) => String(n).padStart(2, '0');

  return (
    <section id="giveaway" className="relative py-10 md:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-5 md:px-8">
        <div className="relative rounded-[28px] overflow-hidden bg-gradient-to-br from-[#1a0f2e] via-[#0B1A2F] to-[#2a1810] border border-[color:var(--color-gold)]/30 shadow-[0_20px_80px_-20px_rgba(245,194,75,0.4)]">

          {/* Animated gold glows */}
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute -top-20 -right-20 w-80 h-80 rounded-full bg-[#F5C24B]/20 blur-[100px] animate-pulse" />
            <div className="absolute -bottom-20 -left-20 w-80 h-80 rounded-full bg-rose-500/15 blur-[100px]" />
            <div className="absolute top-1/2 left-1/3 w-60 h-60 rounded-full bg-amber-400/10 blur-[80px] float-slow" />
          </div>

          {/* Sparkle particles */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {[...Array(14)].map((_, i) => (
              <span
                key={i}
                className="absolute w-1 h-1 rounded-full bg-[color:var(--color-gold)]"
                style={{
                  top: `${(i * 37) % 100}%`,
                  left: `${(i * 71) % 100}%`,
                  opacity: 0.4 + (i % 3) * 0.2,
                  animation: `sparkle ${2 + (i % 4)}s ease-in-out ${i * 0.3}s infinite`,
                }}
              />
            ))}
          </div>

          <div className="relative grid lg:grid-cols-[1.1fr_1fr] gap-6 md:gap-8 p-6 md:p-10 lg:p-14">

            {/* Left: text + CTA */}
            <div className="flex flex-col justify-center order-2 lg:order-1">
              {/* Badge */}
              <div className="flex flex-wrap items-center gap-2 mb-4 md:mb-5">
                <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-l from-rose-500/25 to-rose-500/0 border border-rose-400/40 text-rose-200 text-[11px] md:text-xs font-bold">
                  <Flame size={12} className="animate-pulse" />
                  <span>حصري · لفترة محدودة</span>
                </div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[color:var(--color-gold)]/10 border border-[color:var(--color-gold)]/30 text-[color:var(--color-gold)] text-[11px] md:text-xs font-bold">
                  <Trophy size={12} />
                  <span>سحب شهري</span>
                </div>
              </div>

              {/* Title */}
              <h2 className="font-display text-3xl sm:text-4xl md:text-5xl lg:text-6xl leading-[1.05] font-bold mb-3 md:mb-4">
                اربح <span className="text-gold-gradient">آيفون 17</span>
                <br />
                <span className="text-gold-gradient">برو ماكس</span>
                <span className="inline-block align-middle mx-2 text-2xl md:text-4xl">🏆</span>
              </h2>

              <p className="text-sm md:text-base lg:text-lg text-[color:var(--color-ink-muted)] mb-5 md:mb-6 leading-relaxed max-w-xl">
                أكثر مستخدم يقوم بالإيداع خلال الشهر يفوز بـ
                <span className="text-[color:var(--color-gold)] font-bold mx-1">iPhone 17 Pro Max</span>
                الإصدار الجديد - 1TB، تيتانيوم ذهبي. كلما أودعت أكثر، زادت فرصك في الفوز!
              </p>

              {/* Perks */}
              <div className="grid grid-cols-3 gap-2 md:gap-3 mb-5 md:mb-6">
                {[
                  { Icon: Crown, t: 'حصري', s: 'لعملاء المنصة' },
                  { Icon: Zap, t: 'فوري', s: 'توصيل مجاني' },
                  { Icon: Gift, t: 'مضمون', s: 'شفاف 100%' },
                ].map(p => (
                  <div key={p.t} className="p-2.5 md:p-3 rounded-xl bg-black/30 border border-[color:var(--color-gold)]/15 text-center">
                    <p.Icon size={16} className="mx-auto text-[color:var(--color-gold)] mb-1" />
                    <div className="text-xs md:text-sm font-bold">{p.t}</div>
                    <div className="text-[10px] md:text-[11px] text-[color:var(--color-ink-muted)]">{p.s}</div>
                  </div>
                ))}
              </div>

              {/* Countdown */}
              <div className="mb-5 md:mb-6">
                <div className="text-[11px] md:text-xs text-[color:var(--color-ink-muted)] mb-2 flex items-center gap-1.5">
                  <Sparkles size={12} className="text-[color:var(--color-gold)]" />
                  ينتهي السحب خلال:
                </div>
                <div className="flex items-center gap-2 md:gap-3">
                  {[
                    { v: days, l: 'يوم' },
                    { v: hours, l: 'ساعة' },
                    { v: minutes, l: 'دقيقة' },
                    { v: seconds, l: 'ثانية' },
                  ].map((u) => (
                    <div key={u.l} className="flex-1 relative">
                      <div className="rounded-xl bg-gradient-to-b from-[#F5C24B]/20 to-[#B8860B]/5 border border-[color:var(--color-gold)]/30 p-2 md:p-3 text-center backdrop-blur">
                        <div className="num text-xl md:text-3xl font-extrabold text-gold-gradient">{pad(u.v)}</div>
                        <div className="text-[9px] md:text-[10px] text-[color:var(--color-ink-muted)] mt-0.5">{u.l}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* CTAs */}
              <div className="flex flex-wrap gap-3">
                <Link
                  to="/app/wallet"
                  className="flex-1 sm:flex-none btn-gold px-5 md:px-7 py-3 md:py-3.5 rounded-xl flex items-center justify-center gap-2 text-sm md:text-base"
                >
                  <Gift size={18} /> ادخل السحب الآن <ArrowLeft size={16} />
                </Link>
                <a
                  href="#plans"
                  className="flex-1 sm:flex-none btn-ghost px-5 md:px-7 py-3 md:py-3.5 rounded-xl text-sm md:text-base flex items-center justify-center gap-2"
                >
                  <Trophy size={16} /> شروط السحب
                </a>
              </div>

              <p className="text-[11px] text-[color:var(--color-ink-muted)] mt-4">
                * كل <span className="text-[color:var(--color-gold)] font-bold">$10</span> إيداع = دخول سحب واحد. الإيداعات المؤكدة فقط.
              </p>
            </div>

            {/* Right: iPhone image */}
            <div className="relative order-1 lg:order-2 flex items-center justify-center">
              <div className="relative w-full max-w-[340px] md:max-w-[420px] lg:max-w-none">
                {/* Background halo */}
                <div className="absolute inset-0 bg-gradient-radial from-[#F5C24B]/25 via-[#F5C24B]/5 to-transparent blur-3xl" />

                {/* Prize badge floating */}
                <div className="absolute top-2 right-2 md:top-4 md:right-4 z-20 animate-bounce">
                  <div className="relative">
                    <div className="absolute inset-0 bg-[color:var(--color-gold)] blur-xl opacity-60" />
                    <div className="relative w-16 h-16 md:w-20 md:h-20 rounded-full bg-gradient-to-br from-[#F5E29B] via-[#F5C24B] to-[#B8860B] border-2 border-white/40 flex flex-col items-center justify-center text-[#3a2500] shadow-2xl">
                      <div className="font-display text-[8px] md:text-[9px] font-bold opacity-80">الجائزة</div>
                      <div className="font-display text-base md:text-xl font-black leading-none">$1,599</div>
                      <div className="text-[7px] md:text-[8px] font-bold opacity-70 mt-0.5">VALUE</div>
                    </div>
                  </div>
                </div>

                {/* iPhone image */}
                <div className="relative float-slow">
                  <img
                    src="/images/iphone-giveaway.png"
                    alt="iPhone 17 Pro Max - الجائزة الكبرى"
                    className="w-full h-auto drop-shadow-[0_25px_50px_rgba(245,194,75,0.4)] select-none"
                    draggable={false}
                  />
                </div>

                {/* Bottom caption */}
                <div className="absolute bottom-0 inset-x-0 text-center pointer-events-none">
                  <div className="inline-block px-4 py-1.5 rounded-full bg-black/60 backdrop-blur border border-[color:var(--color-gold)]/40 text-xs md:text-sm font-bold text-[color:var(--color-gold)]">
                    iPhone 17 Pro Max · Titanium Gold
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Marquee ribbon */}
          <div className="relative bg-gradient-to-l from-[#F5C24B] via-[#E0A93A] to-[#B8860B] text-[#07111F] py-2 overflow-hidden">
            <div className="flex items-center gap-8 whitespace-nowrap animate-[marquee_25s_linear_infinite]">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="flex items-center gap-3 text-xs md:text-sm font-extrabold">
                  <Trophy size={14} /> السحب الشهري الكبير
                  <span className="opacity-50">·</span>
                  <Flame size={14} /> iPhone 17 Pro Max
                  <span className="opacity-50">·</span>
                  <Sparkles size={14} /> كلما أودعت أكثر فرصك تزداد
                  <span className="opacity-50">·</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
