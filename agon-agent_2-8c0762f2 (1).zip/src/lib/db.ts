// Simulated database with 4 tables persisted to localStorage.
// Tables: users, plans, subscriptions, transactions

export type PlanTier = 'bronze' | 'silver' | 'gold' | 'diamond';

export interface User {
  id: string;
  name: string;
  email: string;
  password: string; // demo only
  phone?: string;
  balance: number; // available cash USD
  createdAt: string;
}

export interface Plan {
  id: PlanTier;
  nameAr: string;
  price: number;
  dailyPercent: number;
  durationDays: number;
  perks: string[];
  accent: string; // tailwind gradient color tokens
}

export interface Subscription {
  id: string;
  userId: string;
  planId: PlanTier;
  amount: number;
  dailyPercent: number;
  startDate: string;
  endDate: string;
  lastClaimDate: string | null; // ISO date (day granularity)
  totalEarned: number;
  status: 'active' | 'ended';
}

export type TxType =
  | 'deposit'
  | 'withdraw'
  | 'subscribe'
  | 'earning'
  | 'bonus';

export interface Transaction {
  id: string;
  userId: string;
  type: TxType;
  amount: number; // positive=in, negative=out
  note: string;
  createdAt: string;
  meta?: Record<string, any>;
}

export type RequestKind = 'deposit' | 'withdraw';
export type RequestStatus = 'pending' | 'approved' | 'rejected';
export type PaymentMethod = 'usdt_trc20' | 'bnb' | 'sol';

export interface MoneyRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  kind: RequestKind;
  amount: number;
  method: PaymentMethod;
  status: RequestStatus;
  proofDataUrl?: string; // base64 image for deposit proof
  proofName?: string;
  accountDetails?: string; // for withdrawals: iban/wallet address
  note?: string;
  createdAt: string;
  decidedAt?: string;
  decisionNote?: string;
}

export const PLANS: Plan[] = [
  {
    id: 'bronze',
    nameAr: 'البرونزي',
    price: 15,
    dailyPercent: 4.5,
    durationDays: 30,
    perks: ['مناسب للمبتدئين', 'حد أدنى للاشتراك', 'أرباح يومية مضمونة'],
    accent: 'from-amber-700 to-orange-900',
  },
  {
    id: 'silver',
    nameAr: 'الفضي',
    price: 50,
    dailyPercent: 5.5,
    durationDays: 30,
    perks: ['عائد يومي أعلى', 'أولوية في الدعم', 'تقارير أسبوعية'],
    accent: 'from-slate-300 to-slate-600',
  },
  {
    id: 'gold',
    nameAr: 'الذهبي',
    price: 100,
    dailyPercent: 6.5,
    durationDays: 30,
    perks: ['الأكثر شعبية', 'عائد مرتفع', 'دعم VIP على مدار الساعة'],
    accent: 'from-yellow-400 to-amber-700',
  },
  {
    id: 'diamond',
    nameAr: 'الماسي',
    price: 250,
    dailyPercent: 8.5,
    durationDays: 30,
    perks: ['أعلى عائد ممكن', 'سحب فوري', 'مدير حساب شخصي'],
    accent: 'from-cyan-300 to-indigo-600',
  },
];

const K = {
  users: 'muthmir.users',
  subs: 'muthmir.subs',
  txs: 'muthmir.txs',
  session: 'muthmir.session',
  reqs: 'muthmir.requests',
  ownerSession: 'muthmir.ownerSession',
};

// Owner / admin credentials (as requested by product owner)
export const OWNER = {
  email: 'akosbali5@gmail.com',
  password: 'ali6565ali',
  name: 'مالك المنصة',
};

// Withdrawal lock-up: 1 month + 1 week = 37 days from user registration.
export const WITHDRAW_LOCK_DAYS = 37;

export interface WithdrawLockStatus {
  locked: boolean;
  unlockAt: string;        // ISO date when withdrawals become available
  daysLeft: number;        // whole days remaining (floored)
  hoursLeft: number;       // additional hours after days
  minutesLeft: number;     // additional minutes
  secondsLeft: number;     // additional seconds
  totalMsLeft: number;     // raw ms remaining (>= 0)
  progressPercent: number; // 0..100 toward unlock
}

export function getWithdrawLockStatus(user: User, now: Date = new Date()): WithdrawLockStatus {
  const created = new Date(user.createdAt);
  const unlock = new Date(created);
  unlock.setDate(unlock.getDate() + WITHDRAW_LOCK_DAYS);
  const totalMsLeft = Math.max(0, +unlock - +now);
  const locked = totalMsLeft > 0;
  const daysLeft = Math.floor(totalMsLeft / 86_400_000);
  const hoursLeft = Math.floor((totalMsLeft % 86_400_000) / 3_600_000);
  const minutesLeft = Math.floor((totalMsLeft % 3_600_000) / 60_000);
  const secondsLeft = Math.floor((totalMsLeft % 60_000) / 1000);
  const total = WITHDRAW_LOCK_DAYS * 86_400_000;
  const elapsed = Math.min(total, Math.max(0, total - totalMsLeft));
  const progressPercent = Math.min(100, (elapsed / total) * 100);
  return { locked, unlockAt: unlock.toISOString(), daysLeft, hoursLeft, minutesLeft, secondsLeft, totalMsLeft, progressPercent };
}

export function isOwnerEmail(email: string): boolean {
  return email.trim().toLowerCase() === OWNER.email.toLowerCase();
}

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}
function write<T>(key: string, val: T) {
  localStorage.setItem(key, JSON.stringify(val));
}

// --- Cloud cache: store the entire remote store locally for fast reads ---
// It's populated by `syncFromCloud()` in app startup and after each mutation.
export function applyCloudStore(store: {
  users?: User[];
  subscriptions?: Subscription[];
  transactions?: Transaction[];
  requests?: MoneyRequest[];
}) {
  if (store.users) write(K.users, store.users);
  if (store.subscriptions) write(K.subs, store.subscriptions);
  if (store.transactions) write(K.txs, store.transactions);
  if (store.requests) write(K.reqs, store.requests);
}

export const db = {
  // users
  getUsers(): User[] { return read<User[]>(K.users, []); },
  saveUsers(users: User[]) { write(K.users, users); },
  findUserByEmail(email: string) {
    return this.getUsers().find(u => u.email.toLowerCase() === email.toLowerCase());
  },
  findUserById(id: string) {
    return this.getUsers().find(u => u.id === id);
  },
  updateUser(user: User) {
    const users = this.getUsers();
    const i = users.findIndex(u => u.id === user.id);
    if (i >= 0) users[i] = user;
    this.saveUsers(users);
  },
  createUser(u: Omit<User, 'id' | 'createdAt' | 'balance'> & { balance?: number }): User {
    const user: User = {
      ...u,
      id: 'u_' + Math.random().toString(36).slice(2, 10),
      balance: u.balance ?? 0,
      createdAt: new Date().toISOString(),
    };
    const users = this.getUsers();
    users.push(user);
    this.saveUsers(users);
    return user;
  },

  // session
  getSession(): string | null { return read<string | null>(K.session, null); },
  setSession(id: string | null) {
    if (id) localStorage.setItem(K.session, JSON.stringify(id));
    else localStorage.removeItem(K.session);
  },

  // plans
  getPlans(): Plan[] { return PLANS; },
  getPlan(id: PlanTier): Plan | undefined { return PLANS.find(p => p.id === id); },

  // subscriptions
  getSubs(): Subscription[] { return read<Subscription[]>(K.subs, []); },
  saveSubs(subs: Subscription[]) { write(K.subs, subs); },
  subsForUser(userId: string) { return this.getSubs().filter(s => s.userId === userId); },
  updateSub(sub: Subscription) {
    const subs = this.getSubs();
    const i = subs.findIndex(s => s.id === sub.id);
    if (i >= 0) subs[i] = sub;
    this.saveSubs(subs);
  },
  createSub(s: Omit<Subscription, 'id'>): Subscription {
    const sub: Subscription = { ...s, id: 's_' + Math.random().toString(36).slice(2, 10) };
    const subs = this.getSubs();
    subs.push(sub);
    this.saveSubs(subs);
    return sub;
  },

  // transactions
  getTxs(): Transaction[] { return read<Transaction[]>(K.txs, []); },
  saveTxs(txs: Transaction[]) { write(K.txs, txs); },
  txsForUser(userId: string) {
    return this.getTxs()
      .filter(t => t.userId === userId)
      .sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
  },
  createTx(t: Omit<Transaction, 'id' | 'createdAt'>): Transaction {
    const tx: Transaction = {
      ...t,
      id: 't_' + Math.random().toString(36).slice(2, 10),
      createdAt: new Date().toISOString(),
    };
    const txs = this.getTxs();
    txs.push(tx);
    this.saveTxs(txs);
    return tx;
  },

  // money requests (deposits/withdrawals awaiting owner approval)
  getRequests(): MoneyRequest[] { return read<MoneyRequest[]>(K.reqs, []); },
  saveRequests(r: MoneyRequest[]) { write(K.reqs, r); },
  requestsForUser(userId: string) {
    return this.getRequests()
      .filter(r => r.userId === userId)
      .sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
  },
  allRequestsSorted() {
    return this.getRequests().sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
  },
  createRequest(r: Omit<MoneyRequest, 'id' | 'createdAt' | 'status'> & { status?: RequestStatus }): MoneyRequest {
    const req: MoneyRequest = {
      ...r,
      id: 'r_' + Math.random().toString(36).slice(2, 10),
      status: r.status ?? 'pending',
      createdAt: new Date().toISOString(),
    };
    const reqs = this.getRequests();
    reqs.push(req);
    this.saveRequests(reqs);
    return req;
  },
  updateRequest(req: MoneyRequest) {
    const reqs = this.getRequests();
    const i = reqs.findIndex(r => r.id === req.id);
    if (i >= 0) reqs[i] = req;
    this.saveRequests(reqs);
  },

  // owner session
  getOwnerSession(): boolean { return read<boolean>(K.ownerSession, false); },
  setOwnerSession(v: boolean) {
    if (v) localStorage.setItem(K.ownerSession, JSON.stringify(true));
    else localStorage.removeItem(K.ownerSession);
  },
};

// Date helpers
export function toDayKey(d: Date | string): string {
  const date = typeof d === 'string' ? new Date(d) : d;
  return date.toISOString().slice(0, 10);
}
export function todayKey() { return toDayKey(new Date()); }
export function formatMoney(n: number) {
  return (n < 0 ? '-' : '') + '$' + Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
export function formatDateAr(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString('ar-EG', { year: 'numeric', month: 'short', day: 'numeric' });
}
export function formatDateTimeAr(iso: string) {
  const d = new Date(iso);
  return d.toLocaleString('ar-EG', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}
