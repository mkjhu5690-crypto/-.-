import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const CFG_KEY = 'muthmir.supabase.cfg';

export interface SupabaseConfig {
  url: string;
  anonKey: string;
}

export function getSupabaseConfig(): SupabaseConfig | null {
  // Priority 1: build-time env vars
  const envUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
  const envKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
  if (envUrl && envKey) return { url: envUrl, anonKey: envKey };

  // Priority 2: user-provided config via localStorage
  try {
    const raw = localStorage.getItem(CFG_KEY);
    if (!raw) return null;
    const cfg = JSON.parse(raw) as SupabaseConfig;
    if (cfg?.url && cfg?.anonKey) return cfg;
  } catch { /* ignore */ }
  return null;
}

export function saveSupabaseConfig(cfg: SupabaseConfig) {
  localStorage.setItem(CFG_KEY, JSON.stringify(cfg));
}

export function clearSupabaseConfig() {
  localStorage.removeItem(CFG_KEY);
}

let _client: SupabaseClient | null = null;
let _clientKey = '';

export function getSupabase(): SupabaseClient | null {
  const cfg = getSupabaseConfig();
  if (!cfg) return null;
  const key = cfg.url + '::' + cfg.anonKey;
  if (_client && _clientKey === key) return _client;
  _client = createClient(cfg.url, cfg.anonKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      flowType: 'pkce',
    },
  });
  _clientKey = key;
  return _client;
}

export function isSupabaseReady(): boolean {
  return getSupabaseConfig() !== null;
}
