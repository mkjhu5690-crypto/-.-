import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { db, OWNER } from './db';

interface OwnerCtx {
  isOwner: boolean;
  loginOwner: (email: string, password: string) => { ok: boolean; error?: string };
  logoutOwner: () => void;
}

const Ctx = createContext<OwnerCtx | null>(null);

export function OwnerProvider({ children }: { children: React.ReactNode }) {
  const [isOwner, setIsOwner] = useState(false);

  useEffect(() => { setIsOwner(db.getOwnerSession()); }, []);

  const loginOwner = useCallback((email: string, password: string) => {
    // Normalize inputs to be tolerant of copy/paste spaces, zero-width chars, etc.
    const cleanEmail = (email || '').replace(/[\u200B-\u200F\uFEFF]/g, '').trim().toLowerCase();
    const cleanPassword = (password || '').replace(/[\u200B-\u200F\uFEFF]/g, '').trim();
    const ownerEmail = OWNER.email.trim().toLowerCase();
    const ownerPassword = OWNER.password.trim();

    if (cleanEmail !== ownerEmail) {
      return { ok: false, error: 'البريد الإلكتروني غير مطابق لحساب المالك' };
    }
    if (cleanPassword !== ownerPassword) {
      return { ok: false, error: 'كلمة المرور غير صحيحة' };
    }
    db.setOwnerSession(true);
    setIsOwner(true);
    return { ok: true };
  }, []);

  const logoutOwner = useCallback(() => {
    db.setOwnerSession(false);
    setIsOwner(false);
  }, []);

  const value = useMemo(() => ({ isOwner, loginOwner, logoutOwner }), [isOwner, loginOwner, logoutOwner]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useOwner() {
  const c = useContext(Ctx);
  if (!c) throw new Error('useOwner must be inside OwnerProvider');
  return c;
}
