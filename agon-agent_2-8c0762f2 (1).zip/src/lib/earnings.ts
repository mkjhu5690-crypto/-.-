import { db, toDayKey, todayKey, type Subscription, type User } from './db';
import { cloud } from './cloud';

// Returns number of whole calendar days elapsed (capped by subscription end) since lastClaim.
export function daysPendingFor(sub: Subscription): number {
  if (sub.status !== 'active') return 0;
  const now = new Date();
  const end = new Date(sub.endDate);
  const effectiveEnd = now > end ? end : now;
  const last = sub.lastClaimDate ? new Date(sub.lastClaimDate + 'T00:00:00') : new Date(sub.startDate);
  // Count full days between last and effectiveEnd
  const msPerDay = 86400000;
  const diff = Math.floor((+effectiveEnd - +last) / msPerDay);
  return Math.max(0, diff);
}

export function dailyEarningFor(sub: Subscription): number {
  return +(sub.amount * (sub.dailyPercent / 100)).toFixed(2);
}

export function pendingAmountFor(sub: Subscription): number {
  return +(dailyEarningFor(sub) * daysPendingFor(sub)).toFixed(2);
}

export function totalPendingForUser(userId: string): number {
  return +db.subsForUser(userId)
    .reduce((sum, s) => sum + pendingAmountFor(s), 0)
    .toFixed(2);
}

export function claimAll(userId: string): { amount: number; claimedFrom: number } {
  const user = db.findUserById(userId);
  if (!user) return { amount: 0, claimedFrom: 0 };
  const subs = db.subsForUser(userId).filter(s => s.status === 'active');
  let total = 0;
  let count = 0;
  const updatedSubs: Subscription[] = [];
  const newTxs: { subId: string; planId: string; amount: number }[] = [];

  for (const sub of subs) {
    const pending = pendingAmountFor(sub);
    if (pending <= 0) continue;
    total += pending;
    sub.totalEarned = +(sub.totalEarned + pending).toFixed(2);
    sub.lastClaimDate = todayKey();
    if (new Date() >= new Date(sub.endDate)) sub.status = 'ended';
    db.updateSub(sub);
    updatedSubs.push(sub);
    count++;
    const tx = db.createTx({
      userId,
      type: 'earning',
      amount: pending,
      note: `جمع أرباح اشتراك ${sub.planId}`,
      meta: { subId: sub.id, planId: sub.planId },
    });
    newTxs.push({ subId: sub.id, planId: sub.planId, amount: pending });
    // Push to cloud (fire-and-forget)
    cloud.addTx(tx).catch(() => {});
  }
  if (total > 0) {
    user.balance = +(user.balance + total).toFixed(2);
    db.updateUser(user);
    cloud.upsertUser(user).catch(() => {});
  }
  // Push updated subscriptions
  updatedSubs.forEach(s => cloud.upsertSub(s).catch(() => {}));
  return { amount: +total.toFixed(2), claimedFrom: count };
}

export function endSubscriptionsIfDue(userId: string) {
  const now = new Date();
  for (const s of db.subsForUser(userId)) {
    if (s.status === 'active' && now >= new Date(s.endDate) && s.lastClaimDate === toDayKey(s.endDate)) {
      s.status = 'ended';
      db.updateSub(s);
    }
  }
}

export function getActiveSubsStats(user: User | null) {
  if (!user) return { count: 0, invested: 0, earned: 0, daily: 0 };
  const subs = db.subsForUser(user.id);
  const active = subs.filter(s => s.status === 'active');
  return {
    count: active.length,
    invested: +active.reduce((a, s) => a + s.amount, 0).toFixed(2),
    earned: +subs.reduce((a, s) => a + s.totalEarned, 0).toFixed(2),
    daily: +active.reduce((a, s) => a + dailyEarningFor(s), 0).toFixed(2),
  };
}
