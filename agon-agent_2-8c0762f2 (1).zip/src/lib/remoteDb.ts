// Facade over db + cloud: writes go to the cloud first (as source of truth),
// then update the local cache. Reads go from local cache (synced on startup/poll).
// This gives us optimistic updates + shared state across all devices.

import { db, applyCloudStore, type User, type Subscription, type Transaction, type MoneyRequest, type RequestStatus } from './db';
import { cloud, emitCloudChange } from './cloud';

export async function syncFromCloud() {
  try {
    const store = await cloud.fetchStore();
    applyCloudStore(store);
    emitCloudChange();
    return store;
  } catch (e) {
    console.warn('[sync] failed, using local cache', e);
    return null;
  }
}

// Start background polling so the owner's dashboard sees new requests live.
let pollTimer: number | null = null;
export function startCloudPolling(intervalMs = 8000) {
  if (pollTimer) return;
  pollTimer = window.setInterval(() => { syncFromCloud(); }, intervalMs);
  // Also refresh when tab becomes visible
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') syncFromCloud();
  });
}

export const remoteDb = {
  /* ---------------- Users ---------------- */
  async createUser(u: Omit<User, 'id' | 'createdAt' | 'balance'> & { balance?: number }): Promise<User> {
    // Check remote for duplicates first to avoid races.
    const store = await cloud.fetchStore().catch(() => null);
    if (store) applyCloudStore(store);
    const existing = db.findUserByEmail(u.email);
    if (existing) throw new Error('البريد مستخدم بالفعل');

    const user: User = {
      ...u,
      id: 'u_' + Math.random().toString(36).slice(2, 10),
      balance: u.balance ?? 0,
      createdAt: new Date().toISOString(),
    };

    // Optimistic local update
    const users = db.getUsers();
    users.push(user);
    db.saveUsers(users);

    // Push to cloud
    await cloud.upsertUser(user);
    emitCloudChange();
    return user;
  },

  async updateUser(user: User): Promise<void> {
    db.updateUser(user);
    await cloud.upsertUser(user);
    emitCloudChange();
  },

  /* ---------------- Subscriptions ---------------- */
  async createSub(s: Omit<Subscription, 'id'>): Promise<Subscription> {
    const sub: Subscription = { ...s, id: 's_' + Math.random().toString(36).slice(2, 10) };
    const subs = db.getSubs();
    subs.push(sub);
    db.saveSubs(subs);
    await cloud.upsertSub(sub);
    emitCloudChange();
    return sub;
  },

  async updateSub(sub: Subscription): Promise<void> {
    db.updateSub(sub);
    await cloud.upsertSub(sub);
    emitCloudChange();
  },

  /* ---------------- Transactions ---------------- */
  async createTx(t: Omit<Transaction, 'id' | 'createdAt'>): Promise<Transaction> {
    const tx: Transaction = {
      ...t,
      id: 't_' + Math.random().toString(36).slice(2, 10),
      createdAt: new Date().toISOString(),
    };
    const txs = db.getTxs();
    txs.push(tx);
    db.saveTxs(txs);
    await cloud.addTx(tx);
    emitCloudChange();
    return tx;
  },

  /* ---------------- Money Requests ---------------- */
  async createRequest(r: Omit<MoneyRequest, 'id' | 'createdAt' | 'status'> & { status?: RequestStatus }): Promise<MoneyRequest> {
    const req: MoneyRequest = {
      ...r,
      id: 'r_' + Math.random().toString(36).slice(2, 10),
      status: r.status ?? 'pending',
      createdAt: new Date().toISOString(),
    };
    // Local optimistic
    const reqs = db.getRequests();
    reqs.push(req);
    db.saveRequests(reqs);
    // Remote
    await cloud.addRequest(req);
    emitCloudChange();
    return req;
  },

  async updateRequest(req: MoneyRequest): Promise<void> {
    db.updateRequest(req);
    await cloud.updateRequest(req);
    emitCloudChange();
  },

  /* ---------------- Proof upload ---------------- */
  async uploadProof(dataUrl: string, name: string): Promise<string> {
    const { id } = await cloud.uploadProof(dataUrl, name);
    // Return the API path used to retrieve it later
    return `/api/proof?id=${id}`;
  },
};
