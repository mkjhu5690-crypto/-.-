import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { db, type User } from './db';
import { getSupabase, isSupabaseReady } from './supabase';
import { remoteDb, syncFromCloud } from './remoteDb';
import { cloud, onCloudChange } from './cloud';

interface AuthCtx {
  user: User | null;
  loading: boolean;
  supabaseReady: boolean;
  refresh: () => void;
  // Local (demo) auth
  login: (email: string, password: string) => { ok: boolean; error?: string };
  register: (name: string, email: string, password: string, phone?: string) => { ok: boolean; error?: string };
  // Real email auth via Supabase
  signInWithPassword: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  signUpWithPassword: (name: string, email: string, password: string, phone?: string) => Promise<{ ok: boolean; error?: string; needsConfirm?: boolean }>;
  sendMagicLink: (email: string, name?: string) => Promise<{ ok: boolean; error?: string }>;
  resendConfirmation: (email: string) => Promise<{ ok: boolean; error?: string }>;
  resetPassword: (email: string) => Promise<{ ok: boolean; error?: string }>;
  logout: () => void;
}

const Ctx = createContext<AuthCtx | null>(null);

function upsertLocalUserFromSupabase(sbUser: { id: string; email?: string | null; user_metadata?: any }): User {
  // Map supabase auth user to our local user row (for wallet/subs/txs data).
  const id = sbUser.id;
  let u = db.findUserById(id);
  if (u) return u;
  const users = db.getUsers();
  const meta = sbUser.user_metadata ?? {};
  const fresh: User = {
    id,
    name: meta.name || (sbUser.email ? sbUser.email.split('@')[0] : 'مستخدم'),
    email: sbUser.email || '',
    password: '',
    phone: meta.phone || undefined,
    balance: 5, // welcome bonus
    createdAt: new Date().toISOString(),
  };
  users.push(fresh);
  db.saveUsers(users);
  db.createTx({ userId: fresh.id, type: 'bonus', amount: 5, note: 'مكافأة ترحيبية لحساب جديد' });
  return fresh;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [supabaseReady, setSupabaseReady] = useState<boolean>(isSupabaseReady());

  const refresh = useCallback(() => {
    // Refresh currently-loaded user from DB (balance may have changed).
    const sb = getSupabase();
    if (sb) {
      sb.auth.getUser().then(({ data }) => {
        if (data.user) {
          const u = upsertLocalUserFromSupabase(data.user);
          setUser({ ...u });
        } else {
          setUser(null);
        }
      });
      return;
    }
    const id = db.getSession();
    if (!id) { setUser(null); return; }
    const u = db.findUserById(id);
    setUser(u ? { ...u } : null);
  }, []);

  useEffect(() => {
    let unsub: (() => void) | null = null;
    const init = async () => {
      const ready = isSupabaseReady();
      setSupabaseReady(ready);
      const sb = getSupabase();
      if (sb) {
        const { data } = await sb.auth.getSession();
        if (data.session?.user) {
          const u = upsertLocalUserFromSupabase(data.session.user);
          setUser(u);
        }
        const { data: listener } = sb.auth.onAuthStateChange((_event, session) => {
          if (session?.user) {
            const u = upsertLocalUserFromSupabase(session.user);
            setUser({ ...u });
          } else {
            setUser(null);
          }
        });
        unsub = () => listener.subscription.unsubscribe();
      } else {
        // Fallback: local session
        const id = db.getSession();
        if (id) {
          const u = db.findUserById(id);
          setUser(u ?? null);
        }
      }
      setLoading(false);
    };
    init();
    return () => { if (unsub) unsub(); };
  }, []);

  // --- Local (demo) ---
  const login = useCallback((email: string, password: string) => {
    const u = db.findUserByEmail(email);
    if (!u) return { ok: false, error: 'البريد الإلكتروني غير مسجل' };
    if (u.password !== password) return { ok: false, error: 'كلمة المرور غير صحيحة' };
    db.setSession(u.id);
    setUser(u);
    return { ok: true };
  }, []);

  const register = useCallback((name: string, email: string, password: string, phone?: string) => {
    if (!name.trim()) return { ok: false, error: 'الرجاء إدخال الاسم' };
    if (!/^\S+@\S+\.\S+$/.test(email)) return { ok: false, error: 'بريد إلكتروني غير صالح' };
    if (password.length < 4) return { ok: false, error: 'كلمة المرور قصيرة جداً' };
    if (db.findUserByEmail(email)) return { ok: false, error: 'البريد مستخدم بالفعل' };

    // Optimistic local create; push to cloud async. (UX stays snappy.)
    const u = db.createUser({ name, email, password, phone, balance: 0 });
    const bonus = 5;
    u.balance += bonus;
    db.updateUser(u);
    db.createTx({ userId: u.id, type: 'bonus', amount: bonus, note: 'مكافأة ترحيبية لحساب جديد' });
    db.setSession(u.id);
    setUser(u);

    // Push to cloud (don't block UI).
    (async () => {
      try {
        await cloud.upsertUser(u);
        // Also push the bonus transaction.
        const tx = db.txsForUser(u.id)[0];
        if (tx) await cloud.addTx(tx);
      } catch (e) { console.warn('cloud register push failed', e); }
    })();

    return { ok: true };
  }, []);

  // --- Real email auth (Supabase) ---
  const signInWithPassword = useCallback(async (email: string, password: string) => {
    const sb = getSupabase();
    if (!sb) return { ok: false, error: 'لم يتم إعداد نظام المصادقة' };
    const { data, error } = await sb.auth.signInWithPassword({ email, password });
    if (error) return { ok: false, error: translateSbError(error.message) };
    if (data.user) {
      const u = upsertLocalUserFromSupabase(data.user);
      setUser(u);
    }
    return { ok: true };
  }, []);

  const signUpWithPassword = useCallback(async (name: string, email: string, password: string, phone?: string) => {
    const sb = getSupabase();
    if (!sb) return { ok: false, error: 'لم يتم إعداد نظام المصادقة' };
    const { data, error } = await sb.auth.signUp({
      email, password,
      options: {
        data: { name, phone },
        emailRedirectTo: `${window.location.origin}/app`,
      },
    });
    if (error) return { ok: false, error: translateSbError(error.message) };
    if (data.user && data.session) {
      const u = upsertLocalUserFromSupabase(data.user);
      setUser(u);
      return { ok: true };
    }
    // Email confirmation required
    return { ok: true, needsConfirm: true };
  }, []);

  const sendMagicLink = useCallback(async (email: string, name?: string) => {
    const sb = getSupabase();
    if (!sb) return { ok: false, error: 'لم يتم إعداد نظام المصادقة' };
    const { error } = await sb.auth.signInWithOtp({
      email,
      options: {
        data: name ? { name } : undefined,
        emailRedirectTo: `${window.location.origin}/app`,
      },
    });
    if (error) return { ok: false, error: translateSbError(error.message) };
    return { ok: true };
  }, []);

  const resendConfirmation = useCallback(async (email: string) => {
    const sb = getSupabase();
    if (!sb) return { ok: false, error: 'لم يتم إعداد نظام المصادقة' };
    const { error } = await sb.auth.resend({
      type: 'signup',
      email,
      options: { emailRedirectTo: `${window.location.origin}/app` },
    });
    if (error) return { ok: false, error: translateSbError(error.message) };
    return { ok: true };
  }, []);

  const resetPassword = useCallback(async (email: string) => {
    const sb = getSupabase();
    if (!sb) return { ok: false, error: 'لم يتم إعداد نظام المصادقة' };
    const { error } = await sb.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/app`,
    });
    if (error) return { ok: false, error: translateSbError(error.message) };
    return { ok: true };
  }, []);

  const logout = useCallback(() => {
    const sb = getSupabase();
    if (sb) sb.auth.signOut();
    db.setSession(null);
    setUser(null);
  }, []);

  const value = useMemo<AuthCtx>(() => ({
    user, loading, supabaseReady, refresh,
    login, register,
    signInWithPassword, signUpWithPassword, sendMagicLink, resendConfirmation, resetPassword,
    logout,
  }), [user, loading, supabaseReady, refresh, login, register, signInWithPassword, signUpWithPassword, sendMagicLink, resendConfirmation, resetPassword, logout]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error('useAuth must be inside AuthProvider');
  return c;
}

function translateSbError(msg: string): string {
  const m = msg.toLowerCase();
  if (m.includes('invalid login')) return 'البريد أو كلمة المرور غير صحيحة';
  if (m.includes('email not confirmed')) return 'لم يتم تأكيد البريد بعد - تحقق من بريدك';
  if (m.includes('already registered') || m.includes('user already')) return 'البريد الإلكتروني مسجل مسبقاً';
  if (m.includes('password should be')) return 'كلمة المرور ضعيفة - 6 أحرف على الأقل';
  if (m.includes('rate limit')) return 'الكثير من المحاولات - انتظر قليلاً';
  if (m.includes('invalid email')) return 'بريد إلكتروني غير صالح';
  if (m.includes('unable to validate email')) return 'البريد غير صالح';
  return msg;
}
