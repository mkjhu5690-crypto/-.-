// Cloud sync layer — talks to our /api/* serverless endpoints.
// All devices share the same remote store so deposits, users, requests are visible everywhere.

import type { User, Subscription, Transaction, MoneyRequest } from './db';

export interface CloudStore {
  version: number;
  users: User[];
  subscriptions: Subscription[];
  transactions: Transaction[];
  requests: MoneyRequest[];
}

const API_BASE = '/api';

// Prefer the deployed API even in dev (vite proxy / Vercel functions on dev server).
async function apiGet<T = any>(path: string): Promise<T> {
  const r = await fetch(`${API_BASE}${path}`, { method: 'GET', cache: 'no-store' });
  if (!r.ok) throw new Error(`GET ${path} -> ${r.status}`);
  return r.json();
}

async function apiPost<T = any>(path: string, body: any): Promise<T> {
  const r = await fetch(`${API_BASE}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!r.ok) {
    let msg = r.statusText;
    try { const j = await r.json(); msg = j?.error || msg; } catch { /* ignore */ }
    throw new Error(`POST ${path} -> ${msg}`);
  }
  return r.json();
}

export const cloud = {
  async fetchStore(): Promise<CloudStore> {
    return apiGet<CloudStore>('/store');
  },

  async upsertUser(user: User) {
    return apiPost('/store', { action: 'upsertUser', payload: user });
  },
  async upsertSub(sub: Subscription) {
    return apiPost('/store', { action: 'upsertSub', payload: sub });
  },
  async addTx(tx: Transaction) {
    return apiPost('/store', { action: 'addTx', payload: tx });
  },
  async addRequest(req: MoneyRequest) {
    return apiPost('/store', { action: 'addRequest', payload: req });
  },
  async updateRequest(req: MoneyRequest) {
    return apiPost('/store', { action: 'updateRequest', payload: req });
  },

  async uploadProof(dataUrl: string, name: string): Promise<{ id: string; url: string }> {
    return apiPost('/upload', { dataUrl, name });
  },

  async fetchProof(id: string): Promise<{ dataUrl: string; name?: string } | null> {
    try {
      const r = await fetch(`/api/proof?id=${encodeURIComponent(id)}`);
      if (!r.ok) return null;
      return await r.json();
    } catch { return null; }
  },
};

// Simple event bus to notify UI after a cloud operation.
type Listener = () => void;
const listeners = new Set<Listener>();
export function onCloudChange(fn: Listener) { listeners.add(fn); return () => { listeners.delete(fn); }; }
export function emitCloudChange() { listeners.forEach(fn => { try { fn(); } catch { /* ignore */ } }); }
