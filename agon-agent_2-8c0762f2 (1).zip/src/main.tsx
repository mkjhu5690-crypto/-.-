import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import './index.css'
import App from './App.tsx'
import { AuthProvider } from './lib/auth'
import { OwnerProvider } from './lib/owner'
import { syncFromCloud, startCloudPolling } from './lib/remoteDb'

// Initial cloud sync + background polling so all devices stay in sync.
syncFromCloud().finally(() => startCloudPolling(8000));

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <OwnerProvider>
        <AuthProvider>
          <App />
        </AuthProvider>
      </OwnerProvider>
    </BrowserRouter>
  </StrictMode>,
)
