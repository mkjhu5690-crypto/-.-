import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User, Mail, Lock, Phone, ArrowLeft, Gift, CheckCircle2, Sparkles, Settings2, MailCheck } from 'lucide-react';
import Logo from '../components/Logo';
import { useAuth } from '../lib/auth';

export default function Register() {
  const { register, signUpWithPassword, resendConfirmation, supabaseReady } = useAuth();
  const nav = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [confirmSent, setConfirmSent] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      if (supabaseReady) {
        const r = await signUpWithPassword(name, email, password, phone);
        if (!r.ok) { setError(r.error || 'خطأ في التسجيل'); return; }
        if (r.needsConfirm) { setConfirmSent(true); return; }
        nav('/app');
      } else {
        const r = register(name, email, password, phone);
        if (!r.ok) { setError(r.error || 'خطأ في التسجيل'); return; }
        nav('/app');
      }
    } finally { setBusy(false); }
  };

  const resend = async () => {
    setError('');
    setBusy(true);
    const r = await resendConfirmation(email);
    setBusy(false);
    if (!r.ok) setError(r.error || 'تعذر الإرسال');
  };

  if (confirmSent) {
    return (
      <div className="min-h-screen flex items-center justify-center p-5 arabesque">
        <div className="w-full max-w-md">
          <Link to="/" className="flex justify-center mb-8"><Logo /></Link>
          <div className="card card-glow p-8 text-center">
            <div className="w-20 h-20 rounded-full bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center mx-auto mb-5 pulse-glow">
              <MailCheck size={38} className="text-emerald-300" />
            </div>
            <h1 className="font-display text-3xl font-bold mb-3">تحقق من بريدك</h1>
            <p className="text-sm text-[color:var(--color-ink-muted)] mb-1">أرسلنا رابط التأكيد إلى</p>
            <p className="font-bold text-[color:var(--color-gold)] mb-6" dir="ltr">{email}</p>
            <p className="text-xs text-[color:var(--color-ink-muted)] mb-6">اضغط على الرابط في البريد لتأكيد حسابك. إذا لم تجد الرسالة، تحقق من مجلد Spam.</p>
            {error && <div className="mb-4 p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm">{error}</div>}
            <div className="flex gap-2">
              <button onClick={resend} disabled={busy} className="btn-ghost flex-1 py-3 rounded-xl">{busy ? '...' : 'إعادة إرسال'}</button>
              <Link to="/login" className="btn-gold flex-1 py-3 rounded-xl text-center">تسجيل دخول</Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 md:p-5 arabesque safe-top safe-bottom">
      <div className="w-full max-w-md animate-slide-up">
        <Link to="/" className="flex justify-center mb-6 md:mb-8"><Logo /></Link>

        <div className={`mb-4 p-3 rounded-xl border text-xs flex items-center justify-between gap-2 ${supabaseReady ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' : 'bg-amber-500/10 border-amber-500/30 text-amber-300'}`}>
          <div className="flex items-center gap-2">
            {supabaseReady ? <CheckCircle2 size={14} /> : <Sparkles size={14} />}
            <span>{supabaseReady ? 'تسجيل حقيقي مع تأكيد البريد' : 'الوضع التجريبي'}</span>
          </div>
          <Link to="/setup" className="underline decoration-dotted flex items-center gap-1 hover:text-white">
            <Settings2 size={12} /> إعداد
          </Link>
        </div>

        <div className="card card-glow p-6 md:p-8">
          <h1 className="font-display text-2xl md:text-3xl font-bold mb-2">أنشئ حساباً جديداً</h1>
          <p className="text-sm text-[color:var(--color-ink-muted)] mb-5 md:mb-6">ابدأ رحلتك الاستثمارية اليوم</p>

          <div className="mb-5 flex items-center gap-3 p-3 rounded-xl bg-gradient-to-l from-[#F5C24B]/15 to-transparent border border-[color:var(--color-gold)]/25">
            <div className="w-9 h-9 rounded-lg bg-[color:var(--color-gold)]/20 flex items-center justify-center text-[color:var(--color-gold)]"><Gift size={18} /></div>
            <div>
              <div className="text-sm font-bold">مكافأة ترحيبية <span className="num text-[color:var(--color-gold)]">$5</span></div>
              <div className="text-xs text-[color:var(--color-ink-muted)]">تضاف فوراً إلى محفظتك</div>
            </div>
          </div>

          {error && <div className="mb-4 p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm">{error}</div>}

          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="text-xs text-[color:var(--color-ink-muted)] mb-1.5 block">الاسم الكامل</label>
              <div className="relative">
                <User size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-[color:var(--color-ink-muted)]" />
                <input className="input pr-10" value={name} onChange={e => setName(e.target.value)} placeholder="محمد علي" required />
              </div>
            </div>
            <div>
              <label className="text-xs text-[color:var(--color-ink-muted)] mb-1.5 block">البريد الإلكتروني</label>
              <div className="relative">
                <Mail size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-[color:var(--color-ink-muted)]" />
                <input className="input pr-10" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" required dir="ltr" />
              </div>
            </div>
            <div>
              <label className="text-xs text-[color:var(--color-ink-muted)] mb-1.5 block">رقم الهاتف (اختياري)</label>
              <div className="relative">
                <Phone size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-[color:var(--color-ink-muted)]" />
                <input className="input pr-10" value={phone} onChange={e => setPhone(e.target.value)} placeholder="+966 5X XXX XXXX" dir="ltr" />
              </div>
            </div>
            <div>
              <label className="text-xs text-[color:var(--color-ink-muted)] mb-1.5 block">كلمة المرور</label>
              <div className="relative">
                <Lock size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-[color:var(--color-ink-muted)]" />
                <input className="input pr-10" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder={supabaseReady ? 'على الأقل 6 محارف' : 'على الأقل 4 محارف'} required dir="ltr" />
              </div>
            </div>
            <button type="submit" disabled={busy} className="btn-gold w-full py-3 rounded-xl flex items-center justify-center gap-2">
              {busy ? '...' : <>إنشاء الحساب <ArrowLeft size={16} /></>}
            </button>
          </form>

          <div className="mt-6 text-center text-sm text-[color:var(--color-ink-muted)]">
            لديك حساب؟ <Link to="/login" className="text-[color:var(--color-gold)] font-semibold">دخول</Link>
          </div>
        </div>
        <div className="text-center mt-5">
          <Link to="/" className="text-xs text-[color:var(--color-ink-muted)] hover:text-[color:var(--color-ink)]">→ العودة للرئيسية</Link>
        </div>
      </div>
    </div>
  );
}
