import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  LogOut, Users, Wallet as WalletIcon, Layers, Receipt,
  CheckCircle2, XCircle, Clock, ArrowDownCircle, ArrowUpCircle, Search,
  Eye, ExternalLink, TrendingUp, Ban, Shield, Mail, Copy
} from 'lucide-react';
import Logo from '../components/Logo';
import { db, formatDateTimeAr, formatMoney, OWNER, type MoneyRequest, type RequestStatus } from '../lib/db';
import { useOwner } from '../lib/owner';
import { remoteDb, syncFromCloud } from '../lib/remoteDb';
import { onCloudChange } from '../lib/cloud';
import { useEffect } from 'react';

type Tab = 'overview' | 'pending' | 'requests' | 'users' | 'transactions';

export default function OwnerDashboard() {
  const { logoutOwner } = useOwner();
  const nav = useNavigate();
  const [tab, setTab] = useState<Tab>('pending');
  const [statusFilter, setStatusFilter] = useState<'all' | RequestStatus>('all');
  const [kindFilter, setKindFilter] = useState<'all' | 'deposit' | 'withdraw'>('all');
  const [query, setQuery] = useState('');
  const [viewing, setViewing] = useState<MoneyRequest | null>(null);
  const [, bump] = useState(0);
  const refresh = () => bump(x => x + 1);

  const doLogout = () => { logoutOwner(); nav('/'); };

  const copyEmail = () => {
    navigator.clipboard.writeText(OWNER.email).catch(() => {});
  };

  // Auto-refresh the dashboard when cloud data changes (owner sees new deposits live).
  useEffect(() => {
    // Force an immediate pull when owner opens the dashboard.
    syncFromCloud().then(() => refresh());
    return onCloudChange(() => refresh());
  }, []);

  const allReqs = useMemo(() => db.allRequestsSorted(), [tab]); // re-read when tab changes; live refresh via bump
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const reqs = useMemo(() => db.allRequestsSorted(), [tab, statusFilter, kindFilter, query, viewing]);
  const users = useMemo(() => db.getUsers(), [tab, viewing]);
  const txs = useMemo(() => db.getTxs().sort((a,b) => +new Date(b.createdAt) - +new Date(a.createdAt)), [tab, viewing]);
  const subs = useMemo(() => db.getSubs(), [tab, viewing]);

  const pendingReqs = allReqs.filter(r => r.status === 'pending');
  const totalDeposited = allReqs.filter(r => r.kind === 'deposit' && r.status === 'approved').reduce((a, r) => a + r.amount, 0);
  const totalWithdrawn = allReqs.filter(r => r.kind === 'withdraw' && r.status === 'approved').reduce((a, r) => a + r.amount, 0);
  const platformBalance = users.reduce((a, u) => a + u.balance, 0);

  const filtered = reqs.filter(r => {
    if (statusFilter !== 'all' && r.status !== statusFilter) return false;
    if (kindFilter !== 'all' && r.kind !== kindFilter) return false;
    if (query.trim()) {
      const q = query.toLowerCase();
      if (!r.userName.toLowerCase().includes(q) && !r.userEmail.toLowerCase().includes(q)) return false;
    }
    return true;
  });

  const approve = async (req: MoneyRequest) => {
    if (req.status !== 'pending') return;
    const user = db.findUserById(req.userId);
    if (!user) return;
    if (req.kind === 'deposit') {
      user.balance = +(user.balance + req.amount).toFixed(2);
      await remoteDb.updateUser(user);
      await remoteDb.createTx({
        userId: user.id, type: 'deposit', amount: req.amount,
        note: `تمت الموافقة على إيداع عبر ${methodLabel(req.method)}`,
        meta: { method: req.method, requestId: req.id },
      });
    } else {
      // withdraw: balance already deducted when request was created
      await remoteDb.createTx({
        userId: user.id, type: 'withdraw', amount: -req.amount,
        note: `تمت الموافقة على سحب إلى ${methodLabel(req.method)}`,
        meta: { method: req.method, requestId: req.id },
      });
    }
    req.status = 'approved';
    req.decidedAt = new Date().toISOString();
    await remoteDb.updateRequest(req);
    refresh();
    setViewing(null);
  };

  const reject = async (req: MoneyRequest, reason?: string) => {
    if (req.status !== 'pending') return;
    if (req.kind === 'withdraw') {
      // refund the hold amount back to the user balance
      const user = db.findUserById(req.userId);
      if (user) {
        user.balance = +(user.balance + req.amount).toFixed(2);
        await remoteDb.updateUser(user);
      }
    }
    req.status = 'rejected';
    req.decidedAt = new Date().toISOString();
    req.decisionNote = reason;
    await remoteDb.updateRequest(req);
    refresh();
    setViewing(null);
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-20 bg-[color:var(--color-bg-2)]/90 backdrop-blur border-b border-[color:var(--color-border)]">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-5 md:px-8 h-14 md:h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Logo size={32} />
            <div className="hidden md:flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-to-l from-[#F5C24B]/20 to-transparent border border-[#F5C24B]/30 text-[color:var(--color-gold)] text-xs">
              <Shield size={12} /> لوحة المالك
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={doLogout} className="btn-ghost px-3 py-2 rounded-lg text-xs flex items-center gap-2">
              <LogOut size={14} /> خروج
            </button>
          </div>
        </div>
      </header>

      {/* Owner identity banner - prominent */}
      <div className="max-w-[1400px] mx-auto px-4 sm:px-5 md:px-8 pt-4 md:pt-5">
        <div className="card card-glow p-5 md:p-6 relative overflow-hidden">
          <div className="absolute -top-12 -left-12 w-48 h-48 rounded-full bg-[color:var(--color-gold)]/15 blur-3xl pointer-events-none" />
          <div className="relative flex flex-col md:flex-row md:items-center gap-4">
            {/* Avatar */}
            <div className="w-16 h-16 md:w-20 md:h-20 rounded-2xl bg-gradient-to-br from-[#F5E29B] via-[#F5C24B] to-[#B8860B] flex items-center justify-center text-[#07111F] shadow-lg shrink-0">
              <Shield size={32} />
            </div>

            {/* Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <h2 className="font-display text-2xl md:text-3xl font-bold text-gold-gradient">{OWNER.name}</h2>
                <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300">
                  <CheckCircle2 size={10} /> متصل
                </span>
              </div>

              {/* Email - PROMINENT */}
              <div className="flex items-center gap-2 flex-wrap">
                <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[color:var(--color-bg)]/70 border border-[color:var(--color-gold)]/30">
                  <Mail size={16} className="text-[color:var(--color-gold)] shrink-0" />
                  <span className="text-sm md:text-base font-mono font-bold text-[color:var(--color-ink)]" dir="ltr">{OWNER.email}</span>
                  <button onClick={copyEmail} className="text-[color:var(--color-ink-muted)] hover:text-[color:var(--color-gold)] transition" title="نسخ">
                    <Copy size={14} />
                  </button>
                </div>
                <div className="text-xs text-[color:var(--color-ink-muted)]">حساب المالك المعتمد</div>
              </div>
            </div>

            {/* Live stats mini */}
            <div className="grid grid-cols-3 gap-2 md:gap-3 md:border-r md:pr-5 border-[color:var(--color-border)]">
              <MiniBadge label="معلق" value={pendingReqs.length} tone="amber" />
              <MiniBadge label="مستخدم" value={users.length} tone="sky" />
              <MiniBadge label="طلب" value={allReqs.length} tone="gold" />
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-4 sm:px-5 md:px-8 pt-4 md:pt-5 pb-6 space-y-5 md:space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2.5 md:gap-3">
          <StatCard icon={Clock} label="طلبات معلقة" value={String(pendingReqs.length)} tone="amber" highlight={pendingReqs.length > 0} />
          <StatCard icon={Users} label="إجمالي المستخدمين" value={String(users.length)} tone="sky" />
          <StatCard icon={ArrowDownCircle} label="إجمالي الإيداعات" value={formatMoney(totalDeposited)} tone="emerald" />
          <StatCard icon={ArrowUpCircle} label="إجمالي السحوبات" value={formatMoney(totalWithdrawn)} tone="rose" />
          <StatCard icon={WalletIcon} label="أرصدة المنصة" value={formatMoney(platformBalance)} tone="gold" />
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto p-1 rounded-xl bg-[color:var(--color-bg-2)] border border-[color:var(--color-border)] w-fit">
          {([
            { id: 'pending' as const, label: 'طلبات معلقة', icon: Clock, count: pendingReqs.length },
            { id: 'requests' as const, label: 'جميع الطلبات', icon: Receipt, count: allReqs.length },
            { id: 'users' as const, label: 'المستخدمون', icon: Users, count: users.length },
            { id: 'transactions' as const, label: 'المعاملات', icon: Layers, count: txs.length },
          ]).map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} className={`px-4 py-2 rounded-lg text-xs flex items-center gap-2 whitespace-nowrap transition ${tab === t.id ? 'btn-gold' : 'text-[color:var(--color-ink-muted)] hover:text-white'}`}>
              <t.icon size={14} /> {t.label}
              {t.count > 0 && <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${tab === t.id ? 'bg-black/20' : 'bg-[color:var(--color-surface-2)]'}`}>{t.count}</span>}
            </button>
          ))}
        </div>

        {/* Pending tab (quick view) */}
        {tab === 'pending' && (
          <div className="card p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold text-lg">طلبات بانتظار المراجعة</h2>
              {pendingReqs.length > 0 && <div className="text-xs text-amber-300 animate-pulse">● {pendingReqs.length} طلب معلق</div>}
            </div>
            {pendingReqs.length === 0 ? (
              <EmptyState icon={CheckCircle2} title="لا توجد طلبات معلقة" text="كل الطلبات تمت مراجعتها" />
            ) : (
              <div className="space-y-3">
                {pendingReqs.map(r => <RequestRow key={r.id} req={r} onView={() => setViewing(r)} onApprove={() => approve(r)} onReject={() => reject(r, 'تم الرفض من المالك')} />)}
              </div>
            )}
          </div>
        )}

        {/* All Requests */}
        {tab === 'requests' && (
          <div className="card p-5">
            <div className="flex flex-col md:flex-row md:items-center gap-3 mb-4">
              <div className="relative flex-1">
                <Search size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-[color:var(--color-ink-muted)]" />
                <input className="input pr-10" placeholder="ابحث بالاسم أو البريد..." value={query} onChange={e => setQuery(e.target.value)} />
              </div>
              <div className="flex flex-wrap gap-2">
                {(['all','pending','approved','rejected'] as const).map(s => (
                  <button key={s} onClick={() => setStatusFilter(s)} className={`px-3 py-1.5 rounded-lg text-xs ${statusFilter === s ? 'btn-gold' : 'btn-ghost'}`}>{statusArLabel(s)}</button>
                ))}
                <div className="w-px bg-[color:var(--color-border)] mx-1" />
                {(['all','deposit','withdraw'] as const).map(k => (
                  <button key={k} onClick={() => setKindFilter(k)} className={`px-3 py-1.5 rounded-lg text-xs ${kindFilter === k ? 'btn-gold' : 'btn-ghost'}`}>{k === 'all' ? 'الكل' : k === 'deposit' ? 'إيداع' : 'سحب'}</button>
                ))}
              </div>
            </div>
            {filtered.length === 0 ? (
              <EmptyState icon={Ban} title="لا توجد طلبات" text="لم يتم العثور على نتائج مطابقة" />
            ) : (
              <div className="space-y-3">
                {filtered.map(r => <RequestRow key={r.id} req={r} onView={() => setViewing(r)} onApprove={() => approve(r)} onReject={() => reject(r, 'تم الرفض من المالك')} />)}
              </div>
            )}
          </div>
        )}

        {/* Users */}
        {tab === 'users' && (
          <div className="card overflow-hidden">
            <div className="p-5 border-b border-[color:var(--color-border)]"><h2 className="font-bold text-lg">المستخدمون ({users.length})</h2></div>
            {users.length === 0 ? <EmptyState icon={Users} title="لا يوجد مستخدمون بعد" text="سيظهرون هنا بعد التسجيل" /> : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-[color:var(--color-surface)]/50 text-[color:var(--color-ink-muted)] text-xs">
                    <tr>
                      <th className="text-right p-3">المستخدم</th>
                      <th className="text-right p-3">البريد</th>
                      <th className="text-right p-3">الهاتف</th>
                      <th className="text-right p-3">الرصيد</th>
                      <th className="text-right p-3">الاشتراكات</th>
                      <th className="text-right p-3">تاريخ التسجيل</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map(u => {
                      const uSubs = subs.filter(s => s.userId === u.id);
                      const active = uSubs.filter(s => s.status === 'active').length;
                      return (
                        <tr key={u.id} className="border-t border-[color:var(--color-border)] hover:bg-[color:var(--color-surface)]/30">
                          <td className="p-3 font-semibold">{u.name}</td>
                          <td className="p-3 text-[color:var(--color-ink-muted)]" dir="ltr">{u.email}</td>
                          <td className="p-3 text-[color:var(--color-ink-muted)]" dir="ltr">{u.phone || '—'}</td>
                          <td className="p-3 num font-bold text-[color:var(--color-gold)]">{formatMoney(u.balance)}</td>
                          <td className="p-3 num">{active} / {uSubs.length}</td>
                          <td className="p-3 text-[color:var(--color-ink-muted)] text-xs">{formatDateTimeAr(u.createdAt)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* Transactions */}
        {tab === 'transactions' && (
          <div className="card overflow-hidden">
            <div className="p-5 border-b border-[color:var(--color-border)]"><h2 className="font-bold text-lg">كل المعاملات ({txs.length})</h2></div>
            {txs.length === 0 ? <EmptyState icon={TrendingUp} title="لا توجد معاملات" text="سجل المعاملات فارغ" /> : (
              <div className="overflow-x-auto max-h-[600px]">
                <table className="w-full text-sm">
                  <thead className="bg-[color:var(--color-surface)]/50 text-[color:var(--color-ink-muted)] text-xs sticky top-0">
                    <tr>
                      <th className="text-right p-3">النوع</th>
                      <th className="text-right p-3">المستخدم</th>
                      <th className="text-right p-3">الملاحظة</th>
                      <th className="text-right p-3">المبلغ</th>
                      <th className="text-right p-3">التاريخ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {txs.map(t => {
                      const u = users.find(x => x.id === t.userId);
                      return (
                        <tr key={t.id} className="border-t border-[color:var(--color-border)] hover:bg-[color:var(--color-surface)]/30">
                          <td className="p-3">{typeArLabel(t.type)}</td>
                          <td className="p-3">{u?.name || '—'} <span className="text-[color:var(--color-ink-muted)] text-xs" dir="ltr">({u?.email || ''})</span></td>
                          <td className="p-3 text-[color:var(--color-ink-muted)] text-xs">{t.note}</td>
                          <td className={`p-3 num font-bold ${t.amount >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>{t.amount >= 0 ? '+' : ''}{formatMoney(t.amount)}</td>
                          <td className="p-3 text-[color:var(--color-ink-muted)] text-xs">{formatDateTimeAr(t.createdAt)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Detail modal */}
      {viewing && (
        <RequestModal
          req={viewing}
          onClose={() => setViewing(null)}
          onApprove={() => approve(viewing)}
          onReject={(reason) => reject(viewing, reason)}
        />
      )}
    </div>
  );
}

/* ------------------------ Sub components ------------------------ */

function ProofImage({ src }: { src: string }) {
  const [dataUrl, setDataUrl] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    let mounted = true;
    setLoading(true); setError(false);
    // If the src is already a data URL or absolute URL, use as-is.
    if (src.startsWith('data:') || src.startsWith('http')) {
      setDataUrl(src); setLoading(false); return;
    }
    // Otherwise, expect `/api/proof?id=xxx` — fetch and extract dataUrl.
    fetch(src).then(r => r.json()).then(j => {
      if (!mounted) return;
      if (j?.dataUrl) setDataUrl(j.dataUrl);
      else setError(true);
      setLoading(false);
    }).catch(() => { if (mounted) { setError(true); setLoading(false); } });
    return () => { mounted = false; };
  }, [src]);

  if (loading) {
    return (
      <div className="h-48 rounded-xl border border-[color:var(--color-border)] bg-[color:var(--color-surface)]/40 flex items-center justify-center text-sm text-[color:var(--color-ink-muted)] animate-pulse">
        جارٍ تحميل الصورة...
      </div>
    );
  }
  if (error || !dataUrl) {
    return (
      <div className="h-32 rounded-xl border border-rose-500/30 bg-rose-500/5 flex items-center justify-center text-sm text-rose-300">
        تعذر تحميل الصورة
      </div>
    );
  }
  return (
    <div className="relative">
      <a href={dataUrl} target="_blank" rel="noreferrer" className="block rounded-xl overflow-hidden border border-[color:var(--color-border)] bg-black">
        <img src={dataUrl} alt="proof" className="w-full max-h-[400px] object-contain" />
      </a>
      <a href={dataUrl} target="_blank" rel="noreferrer" className="absolute top-2 left-2 px-2 py-1 rounded-lg bg-black/70 text-white text-[11px] flex items-center gap-1 hover:bg-black">
        <ExternalLink size={12} /> فتح في نافذة جديدة
      </a>
    </div>
  );
}

function MiniBadge({ label, value, tone }: { label: string; value: number; tone: 'amber' | 'sky' | 'gold' }) {
  const tones: Record<string, string> = {
    amber: 'text-amber-300 bg-amber-500/10 border-amber-500/30',
    sky: 'text-sky-300 bg-sky-500/10 border-sky-500/30',
    gold: 'text-[color:var(--color-gold)] bg-[color:var(--color-gold)]/10 border-[color:var(--color-gold)]/30',
  };
  return (
    <div className={`px-3 py-2 rounded-xl border text-center ${tones[tone]}`}>
      <div className="num text-lg font-extrabold leading-none">{value}</div>
      <div className="text-[10px] mt-1 opacity-80">{label}</div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, tone, highlight }: { icon: any; label: string; value: string; tone: 'gold'|'emerald'|'rose'|'sky'|'amber'; highlight?: boolean }) {
  const tones: Record<string, string> = {
    gold: 'from-[#F5C24B]/20 to-transparent text-[color:var(--color-gold)]',
    emerald: 'from-emerald-500/20 to-transparent text-emerald-300',
    rose: 'from-rose-500/20 to-transparent text-rose-300',
    sky: 'from-sky-500/20 to-transparent text-sky-300',
    amber: 'from-amber-500/20 to-transparent text-amber-300',
  };
  return (
    <div className={`card p-4 relative overflow-hidden ${highlight ? 'ring-1 ring-amber-400/40' : ''}`}>
      <div className={`absolute -top-10 -left-10 w-32 h-32 rounded-full blur-2xl bg-gradient-to-br ${tones[tone]} opacity-60 pointer-events-none`} />
      <div className="relative flex items-start justify-between">
        <div>
          <div className="text-[11px] text-[color:var(--color-ink-muted)] mb-1">{label}</div>
          <div className="num text-xl md:text-2xl font-extrabold">{value}</div>
        </div>
        <Icon size={18} className={tones[tone].split(' ').find(c => c.startsWith('text-'))} />
      </div>
    </div>
  );
}

function RequestRow({ req, onView, onApprove, onReject }: { req: MoneyRequest; onView: () => void; onApprove: () => void; onReject: () => void }) {
  const isDeposit = req.kind === 'deposit';
  return (
    <div className="flex flex-col md:flex-row md:items-center gap-3 p-4 rounded-xl bg-[color:var(--color-surface)]/50 border border-[color:var(--color-border)] hover:border-[color:var(--color-gold)]/40 transition">
      <div className="flex items-center gap-3 flex-1 min-w-0">
        <div className={`w-11 h-11 shrink-0 rounded-xl flex items-center justify-center border ${isDeposit ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300' : 'bg-rose-500/15 border-rose-500/30 text-rose-300'}`}>
          {isDeposit ? <ArrowDownCircle size={20} /> : <ArrowUpCircle size={20} />}
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-bold">{req.userName}</span>
            <span className="text-[10px] text-[color:var(--color-ink-muted)]" dir="ltr">{req.userEmail}</span>
          </div>
          <div className="text-[11px] text-[color:var(--color-ink-muted)]">
            {isDeposit ? 'إيداع' : 'سحب'} · {methodLabel(req.method)} · {formatDateTimeAr(req.createdAt)}
          </div>
        </div>
      </div>
      <div className="flex items-center gap-3 md:gap-5">
        <div className="text-left">
          <div className={`num text-lg font-bold ${isDeposit ? 'text-emerald-300' : 'text-rose-300'}`}>{formatMoney(req.amount)}</div>
          <StatusPill status={req.status} />
        </div>
        <div className="flex items-center gap-1.5">
          <button onClick={onView} className="btn-ghost p-2 rounded-lg" title="عرض التفاصيل"><Eye size={16} /></button>
          {req.status === 'pending' && (
            <>
              <button onClick={onApprove} className="p-2 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/30 transition" title="موافقة"><CheckCircle2 size={16} /></button>
              <button onClick={onReject} className="p-2 rounded-lg bg-rose-500/20 border border-rose-500/30 text-rose-300 hover:bg-rose-500/30 transition" title="رفض"><XCircle size={16} /></button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function RequestModal({ req, onClose, onApprove, onReject }: { req: MoneyRequest; onClose: () => void; onApprove: () => void; onReject: (reason?: string) => void }) {
  const [reason, setReason] = useState('');
  const isDeposit = req.kind === 'deposit';
  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto" onClick={onClose}>
      <div className="card card-glow p-6 md:p-8 max-w-2xl w-full my-8 relative" onClick={e => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-4 left-4 text-[color:var(--color-ink-muted)] hover:text-white">✕</button>

        <div className="flex items-center gap-3 mb-5">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${isDeposit ? 'bg-emerald-500/15 text-emerald-300' : 'bg-rose-500/15 text-rose-300'}`}>
            {isDeposit ? <ArrowDownCircle size={22} /> : <ArrowUpCircle size={22} />}
          </div>
          <div>
            <h3 className="font-display text-2xl font-bold">تفاصيل طلب {isDeposit ? 'الإيداع' : 'السحب'}</h3>
            <StatusPill status={req.status} />
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-3 mb-5">
          <InfoRow label="المستخدم" value={req.userName} />
          <InfoRow label="البريد" value={req.userEmail} dir="ltr" />
          <InfoRow label="المبلغ" value={formatMoney(req.amount)} highlight />
          <InfoRow label="طريقة الدفع" value={methodLabel(req.method)} />
          <InfoRow label="تاريخ الطلب" value={formatDateTimeAr(req.createdAt)} />
          {req.decidedAt && <InfoRow label="تاريخ القرار" value={formatDateTimeAr(req.decidedAt)} />}
        </div>

        {req.accountDetails && (
          <div className="mb-5 p-4 rounded-xl bg-[color:var(--color-surface)]/50 border border-[color:var(--color-border)]">
            <div className="flex items-center justify-between mb-2 gap-2">
              <div className="text-xs text-[color:var(--color-ink-muted)]">
                {req.kind === 'withdraw' ? 'عنوان محفظة المستخدم لإرسال المبلغ إليها' : 'رقم العملية (TX Hash)'}
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => navigator.clipboard.writeText(req.accountDetails || '')}
                  className="text-[10px] text-[color:var(--color-ink-muted)] hover:text-[color:var(--color-gold)] flex items-center gap-1 px-2 py-1 rounded-md bg-[color:var(--color-bg)]/60"
                  title="نسخ"
                >
                  <Copy size={11} /> نسخ
                </button>
                {explorerLink(req.method, req.accountDetails, req.kind === 'withdraw' ? 'address' : 'tx') && (
                  <a
                    href={explorerLink(req.method, req.accountDetails, req.kind === 'withdraw' ? 'address' : 'tx')!}
                    target="_blank"
                    rel="noreferrer"
                    className="text-[10px] text-[color:var(--color-gold)] hover:underline flex items-center gap-1 px-2 py-1 rounded-md bg-[color:var(--color-gold)]/10"
                  >
                    فتح في المستكشف <ExternalLink size={11} />
                  </a>
                )}
              </div>
            </div>
            <div className="text-sm font-mono break-all p-2 rounded bg-[color:var(--color-bg)]/60" dir="ltr">{req.accountDetails}</div>
          </div>
        )}

        {req.note && (
          <div className="mb-5 p-4 rounded-xl bg-[color:var(--color-surface)]/50 border border-[color:var(--color-border)]">
            <div className="text-xs text-[color:var(--color-ink-muted)] mb-1">ملاحظة المستخدم</div>
            <div className="text-sm">{req.note}</div>
          </div>
        )}

        {req.proofDataUrl && (
          <div className="mb-5">
            <div className="flex items-center justify-between mb-2">
              <div className="text-xs text-[color:var(--color-ink-muted)]">إثبات الدفع {req.proofName && <span className="mx-1">({req.proofName})</span>}</div>
            </div>
            <ProofImage src={req.proofDataUrl} />
          </div>
        )}

        {req.decisionNote && (
          <div className="mb-5 p-4 rounded-xl bg-[color:var(--color-surface)]/50 border border-[color:var(--color-border)]">
            <div className="text-xs text-[color:var(--color-ink-muted)] mb-1">سبب القرار</div>
            <div className="text-sm">{req.decisionNote}</div>
          </div>
        )}

        {req.status === 'pending' && (
          <>
            <div className="mb-4">
              <label className="text-xs text-[color:var(--color-ink-muted)] mb-1.5 block">ملاحظة القرار (اختيارية - تُستخدم عند الرفض)</label>
              <input className="input" value={reason} onChange={e => setReason(e.target.value)} placeholder="سبب الرفض إن وجد..." />
            </div>
            <div className="flex gap-2">
              <button onClick={() => onReject(reason || 'تم الرفض من المالك')} className="flex-1 py-3 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-300 hover:bg-rose-500/25 transition font-bold flex items-center justify-center gap-2">
                <XCircle size={18} /> رفض الطلب
              </button>
              <button onClick={onApprove} className="flex-1 py-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-200 hover:bg-emerald-500/30 transition font-bold flex items-center justify-center gap-2">
                <CheckCircle2 size={18} /> موافقة وتنفيذ
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function InfoRow({ label, value, highlight, dir }: { label: string; value: string; highlight?: boolean; dir?: string }) {
  return (
    <div className="p-3 rounded-xl bg-[color:var(--color-surface)]/50 border border-[color:var(--color-border)]">
      <div className="text-[11px] text-[color:var(--color-ink-muted)] mb-0.5">{label}</div>
      <div className={`text-sm font-bold ${highlight ? 'text-[color:var(--color-gold)] num text-lg' : ''}`} dir={dir}>{value}</div>
    </div>
  );
}

function StatusPill({ status }: { status: RequestStatus }) {
  const map: Record<RequestStatus, string> = {
    pending: 'bg-amber-500/15 text-amber-300 border-amber-500/40',
    approved: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40',
    rejected: 'bg-rose-500/15 text-rose-300 border-rose-500/40',
  };
  return <span className={`inline-block text-[10px] px-2 py-0.5 rounded-full border ${map[status]}`}>{statusArLabel(status)}</span>;
}

function EmptyState({ icon: Icon, title, text }: { icon: any; title: string; text: string }) {
  return (
    <div className="text-center py-16">
      <div className="w-16 h-16 rounded-2xl bg-[color:var(--color-surface)] mx-auto flex items-center justify-center text-[color:var(--color-ink-muted)] mb-3"><Icon size={28} /></div>
      <div className="font-bold mb-1">{title}</div>
      <div className="text-sm text-[color:var(--color-ink-muted)]">{text}</div>
    </div>
  );
}

function explorerLink(method: string, value: string | undefined, kind: 'tx' | 'address'): string | null {
  if (!value) return null;
  const v = value.trim();
  if (method === 'usdt_trc20') {
    return kind === 'tx' ? `https://tronscan.org/#/transaction/${v}` : `https://tronscan.org/#/address/${v}`;
  }
  if (method === 'bnb') {
    return kind === 'tx' ? `https://bscscan.com/tx/${v}` : `https://bscscan.com/address/${v}`;
  }
  if (method === 'sol') {
    return kind === 'tx' ? `https://solscan.io/tx/${v}` : `https://solscan.io/account/${v}`;
  }
  return null;
}

function methodLabel(m: string) {
  if (m === 'usdt_trc20') return 'USDT (TRC20)';
  if (m === 'bnb') return 'BNB (BEP20)';
  if (m === 'sol') return 'SOL (Solana)';
  // backward-compat (legacy records, if any)
  if (m === 'card') return 'بطاقة ائتمانية';
  if (m === 'bank') return 'حوالة بنكية';
  if (m === 'crypto') return 'عملات رقمية';
  return m;
}
function statusArLabel(s: RequestStatus | 'all') {
  return s === 'all' ? 'الكل' : s === 'pending' ? 'معلق' : s === 'approved' ? 'موافق' : 'مرفوض';
}
function typeArLabel(t: string) {
  return t === 'deposit' ? 'إيداع' : t === 'withdraw' ? 'سحب' : t === 'subscribe' ? 'اشتراك' : t === 'earning' ? 'أرباح' : t === 'bonus' ? 'مكافأة' : t;
}
