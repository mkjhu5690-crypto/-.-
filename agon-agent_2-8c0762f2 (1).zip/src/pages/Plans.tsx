import { useState } from 'react';
import PlanCard from '../components/PlanCard';
import Toaster, { toast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import { db, PLANS, type Plan, formatMoney } from '../lib/db';
import { remoteDb } from '../lib/remoteDb';
import { Sparkles, X } from 'lucide-react';

export default function Plans() {
  const { user, refresh } = useAuth();
  const [confirm, setConfirm] = useState<Plan | null>(null);
  if (!user) return null;

  const subscribe = async (plan: Plan) => {
    const u = db.findUserById(user.id)!;
    if (u.balance < plan.price) {
      toast({ kind: 'error', text: 'الرصيد غير كافٍ - يرجى الإيداع أولاً' });
      setConfirm(null);
      return;
    }
    u.balance = +(u.balance - plan.price).toFixed(2);
    await remoteDb.updateUser(u);
    const now = new Date();
    const end = new Date(now);
    end.setDate(end.getDate() + plan.durationDays);
    await remoteDb.createSub({
      userId: u.id,
      planId: plan.id,
      amount: plan.price,
      dailyPercent: plan.dailyPercent,
      startDate: now.toISOString(),
      endDate: end.toISOString(),
      lastClaimDate: null,
      totalEarned: 0,
      status: 'active',
    });
    await remoteDb.createTx({
      userId: u.id,
      type: 'subscribe',
      amount: -plan.price,
      note: `اشتراك في خطة ${plan.nameAr}`,
      meta: { planId: plan.id },
    });
    toast({ kind: 'success', text: `تم الاشتراك في خطة ${plan.nameAr} بنجاح` });
    setConfirm(null);
    refresh();
  };

  return (
    <div className="space-y-6">
      <Toaster />
      <div>
        <h1 className="font-display text-2xl sm:text-3xl md:text-4xl font-bold">خطط <span className="text-gold-gradient">الاستثمار</span></h1>
        <p className="text-xs md:text-sm text-[color:var(--color-ink-muted)] mt-1">اختر الخطة التي تناسب ميزانيتك وابدأ بتحقيق أرباح يومية فوراً</p>
      </div>

      <div className="card p-4 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-[color:var(--color-gold)]/15 text-[color:var(--color-gold)] flex items-center justify-center shrink-0"><Sparkles size={18} /></div>
        <div className="text-sm min-w-0">
          <div>رصيدك الحالي: <span className="num font-bold text-[color:var(--color-gold)]">{formatMoney(user.balance)}</span></div>
          <div className="text-[11px] md:text-xs text-[color:var(--color-ink-muted)]">يتم خصم قيمة الخطة من الرصيد عند الاشتراك</div>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
        {PLANS.map(p => (
          <PlanCard key={p.id} plan={p} featured={p.id === 'gold'} onSelect={() => setConfirm(p)} actionLabel="اشترك الآن" />
        ))}
      </div>

      {/* Confirm modal */}
      {confirm && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-5" onClick={() => setConfirm(null)}>
          <div className="card card-glow p-8 max-w-md w-full relative" onClick={e => e.stopPropagation()}>
            <button onClick={() => setConfirm(null)} className="absolute top-4 left-4 text-[color:var(--color-ink-muted)] hover:text-[color:var(--color-ink)]">
              <X size={20} />
            </button>
            <h3 className="font-display text-2xl font-bold mb-2">تأكيد الاشتراك</h3>
            <p className="text-sm text-[color:var(--color-ink-muted)] mb-5">ستشترك في خطة <span className="text-[color:var(--color-gold)] font-bold">{confirm.nameAr}</span>. هل أنت متأكد؟</p>
            <div className="space-y-2 p-4 rounded-xl bg-[color:var(--color-surface)]/50 border border-[color:var(--color-border)] mb-5">
              <Row label="تكلفة الاشتراك" value={formatMoney(confirm.price)} />
              <Row label="العائد اليومي" value={`${confirm.dailyPercent}% · ${formatMoney(+(confirm.price*confirm.dailyPercent/100).toFixed(2))}`} highlight />
              <Row label="مدة الخطة" value={`${confirm.durationDays} يوماً`} />
              <Row label="إجمالي العائد" value={formatMoney(+(confirm.price*confirm.dailyPercent/100*confirm.durationDays).toFixed(2))} highlight />
            </div>
            <div className="flex gap-2">
              <button onClick={() => setConfirm(null)} className="btn-ghost flex-1 py-3 rounded-xl">إلغاء</button>
              <button onClick={() => subscribe(confirm)} className="btn-gold flex-1 py-3 rounded-xl">تأكيد واشتراك</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Row({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-[color:var(--color-ink-muted)]">{label}</span>
      <span className={`num font-bold ${highlight ? 'text-[color:var(--color-gold)]' : ''}`}>{value}</span>
    </div>
  );
}
