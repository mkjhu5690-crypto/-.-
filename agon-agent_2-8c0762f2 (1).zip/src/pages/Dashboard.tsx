import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Wallet as WalletIcon, Coins, TrendingUp, Layers, HandCoins, ArrowLeft, Sparkles, Calendar } from 'lucide-react';
import StatCard from '../components/StatCard';
import GiveawayTeaser from '../components/GiveawayTeaser';
import Toaster, { toast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import { db, formatMoney, formatDateTimeAr } from '../lib/db';
import WithdrawCountdown from '../components/WithdrawCountdown';
import { claimAll, dailyEarningFor, daysPendingFor, getActiveSubsStats, pendingAmountFor, totalPendingForUser } from '../lib/earnings';

export default function Dashboard() {
  const { user, refresh } = useAuth();
  const [, setTick] = useState(0);
  const bump = () => setTick(t => t + 1);

  const stats = useMemo(() => getActiveSubsStats(user), [user]);
  const pending = useMemo(() => user ? totalPendingForUser(user.id) : 0, [user]);
  const subs = useMemo(() => user ? db.subsForUser(user.id).sort((a,b)=> +new Date(b.startDate) - +new Date(a.startDate)) : [], [user]);
  const recent = useMemo(() => user ? db.txsForUser(user.id).slice(0, 5) : [], [user]);

  if (!user) return null;

  const onClaim = () => {
    if (pending <= 0) { toast({ kind: 'info', text: 'لا توجد أرباح متاحة للجمع الآن' }); return; }
    const r = claimAll(user.id);
    toast({ kind: 'success', text: `تم جمع ${formatMoney(r.amount)} من ${r.claimedFrom} اشتراك` });
    refresh(); bump();
  };

  return (
    <div className="space-y-6">
      <Toaster />

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 md:gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl md:text-4xl font-bold">مرحباً، <span className="text-gold-gradient">{user.name}</span></h1>
          <p className="text-xs md:text-sm text-[color:var(--color-ink-muted)] mt-1">نظرة سريعة على محفظتك واستثماراتك اليوم</p>
        </div>
        <div className="flex items-center gap-2">
          <Link to="/app/wallet" className="flex-1 md:flex-none btn-ghost px-3 md:px-4 py-2.5 rounded-xl text-xs md:text-sm flex items-center justify-center gap-2"><WalletIcon size={16} /> إيداع / سحب</Link>
          <Link to="/app/plans" className="flex-1 md:flex-none btn-gold px-3 md:px-4 py-2.5 rounded-xl text-xs md:text-sm flex items-center justify-center gap-2"><Sparkles size={16} /> خطة جديدة</Link>
        </div>
      </div>

      {/* iPhone Giveaway Teaser - motivates deposits */}
      <GiveawayTeaser />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        <StatCard icon={WalletIcon} tone="gold" label="الرصيد المتاح" value={formatMoney(user.balance)} sub="المحفظة الرئيسية" />
        <StatCard icon={Layers} tone="sky" label="الاشتراكات النشطة" value={String(stats.count)} sub={`مستثمر ${formatMoney(stats.invested)}`} />
        <StatCard icon={TrendingUp} tone="emerald" label="العائد اليومي" value={formatMoney(stats.daily)} sub="مجموع العوائد اليومية" />
        <StatCard icon={Coins} tone="rose" label="إجمالي الأرباح" value={formatMoney(stats.earned)} sub="منذ بداية الحساب" />
      </div>

      {/* Claim */}
      <div className="card card-glow p-5 md:p-8 relative overflow-hidden">
        <div className="absolute -top-16 -left-16 w-64 h-64 rounded-full bg-[color:var(--color-gold)]/15 blur-3xl pointer-events-none" />
        <div className="relative grid md:grid-cols-[1fr_auto] gap-4 md:gap-5 items-center">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs mb-3">
              <Calendar size={12} /> أرباح اليوم متاحة
            </div>
            <div className="text-xs md:text-sm text-[color:var(--color-ink-muted)] mb-1">الأرباح الجاهزة للجمع</div>
            <div className="num text-4xl sm:text-5xl md:text-6xl font-extrabold text-gold-gradient tracking-tight">{formatMoney(pending)}</div>
            <div className="text-[11px] md:text-xs text-[color:var(--color-ink-muted)] mt-2">تحديث تلقائي للأرباح عند منتصف الليل بتوقيتك المحلي</div>
          </div>
          <button onClick={onClaim} disabled={pending<=0} className="btn-gold px-6 md:px-8 py-4 md:py-5 rounded-2xl flex items-center justify-center gap-3 text-base md:text-lg active:scale-95 w-full md:w-auto">
            <HandCoins size={22} /> اجمع الأرباح
          </button>
        </div>
      </div>

      {/* Subs + Recent */}
      <div className="grid lg:grid-cols-3 gap-4 md:gap-5">
        <div className="lg:col-span-2 card p-5 md:p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-lg">اشتراكاتي</h3>
            <Link to="/app/subscriptions" className="text-xs text-[color:var(--color-gold)] flex items-center gap-1">عرض الكل <ArrowLeft size={12} /></Link>
          </div>
          {subs.length === 0 ? (
            <div className="py-12 text-center">
              <div className="text-6xl mb-3">💎</div>
              <div className="font-bold mb-1">لا توجد اشتراكات بعد</div>
              <div className="text-sm text-[color:var(--color-ink-muted)] mb-5">ابدأ بخطة تناسبك لتحقيق أرباح يومية</div>
              <Link to="/app/plans" className="btn-gold inline-block px-6 py-2.5 rounded-xl text-sm">استعرض الخطط</Link>
            </div>
          ) : (
            <div className="space-y-3">
              {subs.slice(0, 4).map(s => {
                const plan = db.getPlan(s.planId)!;
                const pendingAmt = pendingAmountFor(s);
                const days = daysPendingFor(s);
                return (
                  <div key={s.id} className="flex items-center justify-between gap-3 p-4 rounded-xl bg-[color:var(--color-surface)]/60 border border-[color:var(--color-border)]">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-11 h-11 rounded-xl flex items-center justify-center text-xl bg-gradient-to-br from-[color:var(--color-gold)]/30 to-transparent border border-[color:var(--color-gold)]/20">
                        {s.planId === 'bronze' ? '🥉' : s.planId === 'silver' ? '🥈' : s.planId === 'gold' ? '🥇' : '💎'}
                      </div>
                      <div className="min-w-0">
                        <div className="font-bold truncate">خطة {plan.nameAr}</div>
                        <div className="text-xs text-[color:var(--color-ink-muted)]">يومي من {formatMoney(s.amount)} · {s.dailyPercent}%</div>
                      </div>
                    </div>
                    <div className="text-left">
                      <div className="num font-bold text-[color:var(--color-gold)]">{formatMoney(pendingAmt)}</div>
                      <div className="text-[10px] text-[color:var(--color-ink-muted)]">{days} يوم معلق</div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="card p-5 md:p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-lg">آخر المعاملات</h3>
            <Link to="/app/history" className="text-xs text-[color:var(--color-gold)] flex items-center gap-1">السجل <ArrowLeft size={12} /></Link>
          </div>
          {recent.length === 0 ? (
            <div className="text-sm text-[color:var(--color-ink-muted)] py-8 text-center">لا توجد معاملات</div>
          ) : (
            <div className="space-y-2">
              {recent.map(t => (
                <div key={t.id} className="flex items-center justify-between gap-2 p-3 rounded-lg bg-[color:var(--color-surface)]/40">
                  <div className="min-w-0">
                    <div className="text-sm font-semibold truncate">{t.note}</div>
                    <div className="text-[10px] text-[color:var(--color-ink-muted)]">{formatDateTimeAr(t.createdAt)}</div>
                  </div>
                  <div className={`num text-sm font-bold ${t.amount >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>
                    {t.amount >= 0 ? '+' : ''}{formatMoney(t.amount)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Daily breakdown per plan for active subs */}
      {subs.filter(s=>s.status==='active').length > 0 && (
        <div className="card p-6">
          <h3 className="font-bold text-lg mb-4">العوائد اليومية حسب الاشتراك</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {subs.filter(s=>s.status==='active').map(s => {
              const plan = db.getPlan(s.planId)!;
              return (
                <div key={s.id} className="p-4 rounded-xl bg-[color:var(--color-surface)]/60 border border-[color:var(--color-border)]">
                  <div className="text-xs text-[color:var(--color-ink-muted)]">{plan.nameAr}</div>
                  <div className="num font-bold text-[color:var(--color-gold)]">{formatMoney(dailyEarningFor(s))}</div>
                  <div className="text-[10px] text-[color:var(--color-ink-muted)] mt-1">يومياً</div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
