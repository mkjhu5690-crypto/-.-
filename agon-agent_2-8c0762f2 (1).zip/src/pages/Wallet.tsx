import { useMemo, useState } from 'react';
import {
  ArrowDownCircle, ArrowUpCircle, Wallet as WalletIcon, Upload, X, Clock,
  CheckCircle2, XCircle, Image as ImageIcon, Copy, Info, Link as LinkIcon,
  ExternalLink, AlertTriangle
} from 'lucide-react';
import StatCard from '../components/StatCard';
import Toaster, { toast } from '../components/Toast';
import WithdrawCountdown from '../components/WithdrawCountdown';
import { useAuth } from '../lib/auth';
import { db, formatDateTimeAr, formatMoney, getWithdrawLockStatus, type PaymentMethod, type RequestStatus } from '../lib/db';
import { remoteDb } from '../lib/remoteDb';
import { onCloudChange } from '../lib/cloud';
import { useEffect } from 'react';

type Mode = 'deposit' | 'withdraw';

interface CryptoOption {
  id: PaymentMethod;
  name: string;
  symbol: string;
  network: string;
  color: string; // tailwind classes for accent
  gradient: string;
  logo: string; // emoji/text logo
  address: string;
  // payment link template (opens wallets automatically when possible)
  paymentLink: (amount: number) => string;
  // placeholder shown for user's receiving address during withdrawals
  addrPlaceholder: string;
  addrExample: string;
  notice: string;
}

const CRYPTOS: CryptoOption[] = [
  {
    id: 'usdt_trc20',
    name: 'Tether',
    symbol: 'USDT',
    network: 'TRC20 (Tron)',
    color: 'emerald',
    gradient: 'from-emerald-400 to-teal-600',
    logo: '₮',
    address: 'TX2GzHPm27LutkfCEHPxRxaHui2kRY9q5a',
    paymentLink: (amt) => `tron:TX2GzHPm27LutkfCEHPxRxaHui2kRY9q5a?amount=${amt}&token=USDT`,
    addrPlaceholder: 'عنوان محفظة USDT (TRC20) - يبدأ بـ T',
    addrExample: 'T...',
    notice: 'الشبكة: TRC20 فقط. أي تحويل على شبكة أخرى سيؤدي لفقدان المبلغ.',
  },
  {
    id: 'bnb',
    name: 'BNB',
    symbol: 'BNB',
    network: 'BEP20 (BSC)',
    color: 'amber',
    gradient: 'from-yellow-300 to-amber-600',
    logo: '◆',
    address: '0x6825d944882b6f117b7635f3f284a2c9837038b6',
    paymentLink: (amt) => `https://link.trustwallet.com/send?coin=20000714&address=0x6825d944882b6f117b7635f3f284a2c9837038b6&amount=${amt}`,
    addrPlaceholder: 'عنوان محفظة BNB (BEP20) - يبدأ بـ 0x',
    addrExample: '0x...',
    notice: 'الشبكة: Binance Smart Chain (BEP20). احرص على اختيار الشبكة الصحيحة.',
  },
  {
    id: 'sol',
    name: 'Solana',
    symbol: 'SOL',
    network: 'Solana',
    color: 'violet',
    gradient: 'from-fuchsia-400 via-violet-500 to-indigo-600',
    logo: '◎',
    address: 'DfGLh6ACdipPnUNpqH73ppKxtWe4yfm12S2QFwC4AQR',
    paymentLink: (amt) => `solana:DfGLh6ACdipPnUNpqH73ppKxtWe4yfm12S2QFwC4AQR?amount=${amt}`,
    addrPlaceholder: 'عنوان محفظة Solana',
    addrExample: '7xKX...',
    notice: 'شبكة Solana. لا ترسل SOL إلى عناوين شبكات أخرى.',
  },
];

export default function Wallet() {
  const { user, refresh } = useAuth();
  const [mode, setMode] = useState<Mode>('deposit');
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<PaymentMethod>('usdt_trc20');
  const [proofData, setProofData] = useState<string>('');
  const [proofName, setProofName] = useState<string>('');
  const [txHash, setTxHash] = useState('');
  const [userAddress, setUserAddress] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [, bump] = useState(0);

  useEffect(() => onCloudChange(() => bump(x => x + 1)), []);

  const myRequests = useMemo(() => user ? db.requestsForUser(user.id) : [], [user, bump]);
  const pendingHold = useMemo(() =>
    myRequests.filter(r => r.kind === 'withdraw' && r.status === 'pending')
      .reduce((a, r) => a + r.amount, 0), [myRequests]);

  if (!user) return null;

  const selected = CRYPTOS.find(c => c.id === method)!;
  const presets = [15, 50, 100, 250, 500, 1000];

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 5 * 1024 * 1024) { toast({ kind: 'error', text: 'حجم الصورة أكبر من 5MB' }); return; }
    if (!f.type.startsWith('image/')) { toast({ kind: 'error', text: 'يجب رفع صورة' }); return; }
    const reader = new FileReader();
    reader.onload = () => { setProofData(reader.result as string); setProofName(f.name); };
    reader.readAsDataURL(f);
  };

  const clearProof = () => { setProofData(''); setProofName(''); };

  const copyText = (text: string) => {
    navigator.clipboard.writeText(text).then(
      () => toast({ kind: 'success', text: 'تم النسخ إلى الحافظة' }),
      () => toast({ kind: 'error', text: 'تعذر النسخ' }),
    );
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) { toast({ kind: 'error', text: 'يرجى إدخال مبلغ صحيح' }); return; }
    if (amt < 5) { toast({ kind: 'error', text: 'الحد الأدنى $5' }); return; }
    setBusy(true);
    try {
      if (mode === 'deposit') {
        if (!proofData) { toast({ kind: 'error', text: 'يجب رفع صورة إثبات التحويل' }); return; }

        // 1) Upload the proof image to the cloud
        toast({ kind: 'info', text: 'جارٍ رفع إثبات التحويل...' });
        let proofUrl = '';
        try {
          proofUrl = await remoteDb.uploadProof(proofData, proofName || 'proof.png');
        } catch (err: any) {
          toast({ kind: 'error', text: 'تعذر رفع الصورة - ' + (err?.message || 'خطأ') });
          return;
        }

        // 2) Create request referencing uploaded proof (URL, not the heavy base64)
        await remoteDb.createRequest({
          userId: user.id,
          userName: user.name,
          userEmail: user.email,
          kind: 'deposit',
          amount: amt,
          method,
          proofDataUrl: proofUrl,
          proofName,
          accountDetails: txHash.trim() || undefined,
          note: note.trim() || undefined,
        });
        toast({ kind: 'success', text: `تم إرسال طلب إيداع ${formatMoney(amt)} إلى المالك للمراجعة` });
      } else {
        const u = db.findUserById(user.id)!;
        // Enforce 37-day lock-up period before first withdrawal
        const lock = getWithdrawLockStatus(u);
        if (lock.locked) {
          toast({ kind: 'error', text: `السحب غير متاح بعد - متبقي ${lock.daysLeft} يوم و ${lock.hoursLeft} ساعة` });
          return;
        }
        if (amt > u.balance) { toast({ kind: 'error', text: 'الرصيد غير كافٍ' }); return; }
        if (!userAddress.trim()) { toast({ kind: 'error', text: 'يجب إدخال عنوان محفظتك لاستلام المبلغ' }); return; }
        if (userAddress.trim().length < 20) { toast({ kind: 'error', text: 'عنوان المحفظة غير صالح' }); return; }

        // Hold balance (local + cloud)
        u.balance = +(u.balance - amt).toFixed(2);
        await remoteDb.updateUser(u);

        await remoteDb.createRequest({
          userId: user.id,
          userName: user.name,
          userEmail: user.email,
          kind: 'withdraw',
          amount: amt,
          method,
          accountDetails: userAddress.trim(),
          note: note.trim() || undefined,
        });
        toast({ kind: 'success', text: `تم إرسال طلب سحب ${formatMoney(amt)} إلى المالك للمراجعة` });
      }
      setAmount(''); setNote(''); setUserAddress(''); setTxHash(''); clearProof();
      refresh(); bump(x => x + 1);
    } catch (err: any) {
      toast({ kind: 'error', text: 'حدث خطأ: ' + (err?.message || 'غير معروف') });
    } finally { setBusy(false); }
  };

  return (
    <div className="space-y-6">
      <Toaster />
      <div>
        <h1 className="font-display text-3xl md:text-4xl font-bold">المحفظة <span className="text-gold-gradient">المالية</span></h1>
        <p className="text-sm text-[color:var(--color-ink-muted)] mt-1">إيداع وسحب بالعملات الرقمية فقط - USDT · BNB · SOL</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
        <StatCard icon={WalletIcon} tone="gold" label="الرصيد المتاح" value={formatMoney(user.balance)} sub={pendingHold > 0 ? `محجوز للمراجعة: ${formatMoney(pendingHold)}` : undefined} />
        <StatCard icon={ArrowDownCircle} tone="emerald" label="إجمالي الإيداعات" value={formatMoney(sumByType(user.id, 'deposit'))} />
        <StatCard icon={ArrowUpCircle} tone="rose" label="إجمالي السحوبات" value={formatMoney(Math.abs(sumByType(user.id, 'withdraw')))} />
      </div>

      {/* Withdrawal lock countdown - always visible so users know when they can withdraw */}
      <WithdrawCountdown user={user} />

      <div className="card card-glow p-5 md:p-8">
        {/* Tabs */}
        <div className="grid grid-cols-2 sm:inline-flex p-1 rounded-xl bg-[color:var(--color-bg-2)] border border-[color:var(--color-border)] mb-5 md:mb-6 w-full sm:w-auto">
          <button onClick={() => setMode('deposit')} className={`px-5 py-2.5 rounded-lg text-sm flex items-center justify-center gap-2 transition ${mode==='deposit' ? 'btn-gold' : 'text-[color:var(--color-ink-muted)]'}`}>
            <ArrowDownCircle size={16} /> إيداع
          </button>
          <button onClick={() => setMode('withdraw')} className={`px-5 py-2.5 rounded-lg text-sm flex items-center justify-center gap-2 transition ${mode==='withdraw' ? 'btn-gold' : 'text-[color:var(--color-ink-muted)]'}`}>
            <ArrowUpCircle size={16} /> سحب
          </button>
        </div>

        <form onSubmit={submit} className="space-y-6">
          {/* Crypto selector */}
          <div>
            <label className="text-xs text-[color:var(--color-ink-muted)] mb-2 block">اختر العملة الرقمية</label>
            <div className="grid grid-cols-3 gap-2 md:gap-3">
              {CRYPTOS.map(c => {
                const active = method === c.id;
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setMethod(c.id)}
                    className={`p-3 md:p-4 rounded-xl md:rounded-2xl border text-right transition relative overflow-hidden active:scale-[0.98] ${active ? 'border-[color:var(--color-gold)] bg-[color:var(--color-gold)]/5 shadow-lg' : 'border-[color:var(--color-border)] bg-[color:var(--color-surface)]/40 hover:border-[color:var(--color-gold)]/40'}`}
                  >
                    {active && <div className="absolute top-2 left-2 w-5 h-5 rounded-full bg-[color:var(--color-gold)] flex items-center justify-center text-[#07111F]"><CheckCircle2 size={12} /></div>}
                    <div className={`w-10 h-10 md:w-11 md:h-11 rounded-lg md:rounded-xl bg-gradient-to-br ${c.gradient} flex items-center justify-center text-white text-xl md:text-2xl font-bold shadow-lg`}>
                      {c.logo}
                    </div>
                    <div className="font-bold mt-2 md:mt-3 text-sm md:text-base">{c.name}</div>
                    <div className="text-[10px] md:text-[11px] text-[color:var(--color-ink-muted)] leading-tight">{c.symbol} · {c.network}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Amount */}
          <div>
            <label className="text-xs text-[color:var(--color-ink-muted)] mb-2 block">المبلغ (USD)</label>
            <div className="relative">
              <span className="absolute top-1/2 -translate-y-1/2 right-4 text-xl md:text-2xl text-[color:var(--color-gold)] num">$</span>
              <input
                className="input pr-10 py-4 md:py-5 text-2xl md:text-3xl font-bold num"
                type="number" step="0.01" min="5" inputMode="decimal"
                value={amount}
                onChange={e => setAmount(e.target.value)}
                placeholder="0.00"
                required
              />
            </div>
            <div className="flex flex-wrap gap-1.5 md:gap-2 mt-3">
              {presets.map(p => (
                <button key={p} type="button" onClick={() => setAmount(String(p))} className="btn-ghost px-3 md:px-4 py-1.5 rounded-lg text-xs num active:scale-95">
                  ${p}
                </button>
              ))}
            </div>
          </div>

          {/* Deposit flow */}
          {mode === 'deposit' && (
            <>
              {/* Wallet address card */}
              <div className={`relative rounded-2xl p-[1.5px] bg-gradient-to-br ${selected.gradient}`}>
                <div className="rounded-[15px] bg-[color:var(--color-bg-2)] p-5 md:p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${selected.gradient} flex items-center justify-center text-white font-bold`}>
                          {selected.logo}
                        </div>
                        <div>
                          <div className="font-bold">{selected.name} ({selected.symbol})</div>
                          <div className="text-[10px] text-[color:var(--color-ink-muted)]">{selected.network}</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mb-3">
                    <div className="text-xs text-[color:var(--color-ink-muted)] mb-1.5">عنوان محفظة المنصة (للإيداع)</div>
                    <div className="flex items-stretch gap-2">
                      <div className="flex-1 min-w-0 p-3 rounded-lg bg-[color:var(--color-bg)]/80 border border-[color:var(--color-border)] font-mono text-xs md:text-sm break-all" dir="ltr">
                        {selected.address}
                      </div>
                      <button type="button" onClick={() => copyText(selected.address)} className="btn-ghost px-3 rounded-lg shrink-0 flex items-center gap-1" title="نسخ العنوان">
                        <Copy size={14} /> <span className="hidden sm:inline text-xs">نسخ</span>
                      </button>
                    </div>
                  </div>

                  {/* Payment link button */}
                  <a
                    href={amount && parseFloat(amount) > 0 ? selected.paymentLink(parseFloat(amount)) : '#'}
                    target="_blank"
                    rel="noreferrer"
                    onClick={(e) => { if (!amount || parseFloat(amount) <= 0) { e.preventDefault(); toast({ kind: 'info', text: 'أدخل المبلغ أولاً لتوليد رابط الدفع' }); } }}
                    className={`w-full py-3 rounded-xl flex items-center justify-center gap-2 text-sm font-bold transition bg-gradient-to-l ${selected.gradient} text-white hover:brightness-110`}
                  >
                    <LinkIcon size={16} /> فتح رابط الدفع في المحفظة
                  </a>
                  <div className="text-[11px] text-[color:var(--color-ink-muted)] mt-2 text-center">
                    يدعم Trust Wallet · MetaMask · Phantom · Binance
                  </div>
                </div>
              </div>

              {/* Network warning */}
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs flex gap-2">
                <AlertTriangle size={16} className="shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold mb-0.5">تنبيه مهم</div>
                  <div className="opacity-90">{selected.notice}</div>
                </div>
              </div>

              {/* TX hash */}
              <div>
                <label className="text-xs text-[color:var(--color-ink-muted)] mb-2 block">رقم العملية (TX Hash) - اختياري</label>
                <input
                  className="input font-mono text-xs"
                  value={txHash}
                  onChange={e => setTxHash(e.target.value)}
                  placeholder="0x... أو hash العملية من المحفظة"
                  dir="ltr"
                />
              </div>

              {/* Proof upload */}
              <div>
                <label className="text-xs text-[color:var(--color-ink-muted)] mb-2 block">إثبات التحويل (Screenshot) *</label>
                {!proofData ? (
                  <label className="flex flex-col items-center justify-center gap-2 p-8 rounded-xl border-2 border-dashed border-[color:var(--color-border)] hover:border-[color:var(--color-gold)]/60 cursor-pointer transition bg-[color:var(--color-surface)]/30">
                    <div className="w-14 h-14 rounded-2xl bg-[color:var(--color-gold)]/15 text-[color:var(--color-gold)] flex items-center justify-center">
                      <Upload size={22} />
                    </div>
                    <div className="text-sm font-bold">اضغط لرفع لقطة شاشة التحويل</div>
                    <div className="text-xs text-[color:var(--color-ink-muted)]">PNG / JPG - حتى 5MB</div>
                    <input type="file" accept="image/*" className="hidden" onChange={onFile} />
                  </label>
                ) : (
                  <div className="relative rounded-xl overflow-hidden border border-[color:var(--color-border)] bg-black">
                    <img src={proofData} alt="proof" className="w-full max-h-[320px] object-contain" />
                    <button type="button" onClick={clearProof} className="absolute top-2 left-2 w-8 h-8 rounded-full bg-black/70 border border-white/20 text-white flex items-center justify-center hover:bg-rose-500/80 transition"><X size={16} /></button>
                    <div className="absolute bottom-0 inset-x-0 p-2 bg-gradient-to-t from-black/80 to-transparent flex items-center gap-2 text-xs text-white">
                      <ImageIcon size={14} /> {proofName}
                    </div>
                  </div>
                )}
              </div>
            </>
          )}

          {/* Withdraw flow */}
          {mode === 'withdraw' && (
            <>
              <div className={`relative rounded-2xl p-[1.5px] bg-gradient-to-br ${selected.gradient}`}>
                <div className="rounded-[15px] bg-[color:var(--color-bg-2)] p-5">
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${selected.gradient} flex items-center justify-center text-white text-xl font-bold`}>
                      {selected.logo}
                    </div>
                    <div>
                      <div className="font-bold">سحب بعملة {selected.name}</div>
                      <div className="text-[10px] text-[color:var(--color-ink-muted)]">{selected.network}</div>
                    </div>
                  </div>

                  <label className="text-xs text-[color:var(--color-ink-muted)] mb-2 block">
                    عنوان محفظتك لاستلام {selected.symbol} *
                  </label>
                  <div className="relative">
                    <LinkIcon size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-[color:var(--color-ink-muted)]" />
                    <input
                      className="input pr-10 font-mono text-xs"
                      value={userAddress}
                      onChange={e => setUserAddress(e.target.value)}
                      placeholder={selected.addrPlaceholder}
                      dir="ltr"
                      required
                    />
                  </div>
                  <div className="flex items-start gap-2 mt-2 text-[11px] text-[color:var(--color-ink-muted)]">
                    <Info size={12} className="mt-0.5 shrink-0" />
                    <div>مثال: <span className="font-mono" dir="ltr">{selected.addrExample}</span> · تأكد من صحة العنوان والشبكة. الأموال المرسلة إلى عنوان خاطئ لا يمكن استرجاعها.</div>
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-200 text-xs flex gap-2">
                <AlertTriangle size={16} className="shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold mb-0.5">تحذير: تحقق من العنوان جيداً</div>
                  <div className="opacity-90">سيُحجز المبلغ من رصيدك فوراً. سيعيده النظام إذا رُفض الطلب. المعاملات على البلوكتشين نهائية ولا يمكن التراجع عنها.</div>
                </div>
              </div>
            </>
          )}

          <div>
            <label className="text-xs text-[color:var(--color-ink-muted)] mb-2 block">ملاحظة (اختياري)</label>
            <textarea className="input resize-none" rows={2} value={note} onChange={e => setNote(e.target.value)} placeholder="أي معلومات إضافية..." />
          </div>

          {(() => {
            const lock = getWithdrawLockStatus(user);
            const blockWithdraw = mode === 'withdraw' && lock.locked;
            return (
              <>
                <button
                  type="submit"
                  disabled={busy || blockWithdraw}
                  className="btn-gold w-full py-4 rounded-xl text-base md:text-lg flex items-center justify-center gap-2 active:scale-[0.99]"
                >
                  {mode === 'deposit'
                    ? <><ArrowDownCircle size={20} /> إرسال طلب الإيداع للمراجعة</>
                    : blockWithdraw
                      ? <><AlertTriangle size={20} /> السحب مقفل - متبقي {lock.daysLeft}ي {lock.hoursLeft}س</>
                      : <><ArrowUpCircle size={20} /> إرسال طلب السحب للمراجعة</>
                  }
                </button>

                {blockWithdraw && (
                  <div className="mt-3 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs flex items-start gap-2">
                    <AlertTriangle size={14} className="shrink-0 mt-0.5" />
                    <div>
                      السحب متاح بعد <span className="font-bold">{lock.daysLeft} يوم و {lock.hoursLeft} ساعة</span>. يمكنك الاستمرار في الإيداع والاستثمار خلال فترة القفل.
                    </div>
                  </div>
                )}

                <p className="text-[11px] md:text-xs text-[color:var(--color-ink-muted)] text-center mt-3">
                  ⓘ تتم مراجعة كل الطلبات من قبل مالك المنصة خلال 15 دقيقة - ساعتين
                </p>
              </>
            );
          })()}
        </form>
      </div>

      {/* My requests */}
      <div className="card p-6">
        <h3 className="font-bold text-lg mb-4">طلباتي ({myRequests.length})</h3>
        {myRequests.length === 0 ? (
          <div className="text-center py-10 text-sm text-[color:var(--color-ink-muted)]">لا توجد طلبات بعد</div>
        ) : (
          <div className="space-y-2">
            {myRequests.map(r => {
              const crypto = CRYPTOS.find(c => c.id === r.method);
              return (
                <div key={r.id} className="flex items-center justify-between gap-3 p-4 rounded-xl bg-[color:var(--color-surface)]/50 border border-[color:var(--color-border)]">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${r.kind === 'deposit' ? 'bg-emerald-500/15 text-emerald-300' : 'bg-rose-500/15 text-rose-300'}`}>
                      {r.kind === 'deposit' ? <ArrowDownCircle size={18} /> : <ArrowUpCircle size={18} />}
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-bold">
                        {r.kind === 'deposit' ? 'طلب إيداع' : 'طلب سحب'}
                        {crypto && <span className="mx-1 text-[color:var(--color-ink-muted)]">· {crypto.symbol}</span>}
                      </div>
                      <div className="text-[11px] text-[color:var(--color-ink-muted)]">{formatDateTimeAr(r.createdAt)}</div>
                      {r.decisionNote && <div className="text-[11px] text-[color:var(--color-ink-muted)] mt-0.5">💬 {r.decisionNote}</div>}
                    </div>
                  </div>
                  <div className="text-left shrink-0">
                    <div className={`num font-bold ${r.kind === 'deposit' ? 'text-emerald-300' : 'text-rose-300'}`}>{formatMoney(r.amount)}</div>
                    <StatusBadge status={r.status} />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: RequestStatus }) {
  const map = {
    pending:  { cls: 'text-amber-300 bg-amber-500/10 border-amber-500/30', Icon: Clock, label: 'معلق' },
    approved: { cls: 'text-emerald-300 bg-emerald-500/10 border-emerald-500/30', Icon: CheckCircle2, label: 'تمت الموافقة' },
    rejected: { cls: 'text-rose-300 bg-rose-500/10 border-rose-500/30', Icon: XCircle, label: 'مرفوض' },
  } as const;
  const s = map[status];
  return (
    <span className={`inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full border ${s.cls} mt-0.5`}>
      <s.Icon size={10} /> {s.label}
    </span>
  );
}

function sumByType(userId: string, type: string) {
  return +db.txsForUser(userId).filter(t => t.type === type).reduce((a, t) => a + t.amount, 0).toFixed(2);
}

// Export also used by OwnerDashboard to render crypto names consistently
export const METHOD_LABELS: Record<PaymentMethod, string> = {
  usdt_trc20: 'USDT (TRC20)',
  bnb: 'BNB (BEP20)',
  sol: 'SOL (Solana)',
};

// Unused local but kept for clarity of the "ExternalLink" import if we need it later
void ExternalLink;
