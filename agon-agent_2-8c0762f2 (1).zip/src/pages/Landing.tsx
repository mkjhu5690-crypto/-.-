import { Link } from 'react-router-dom';
import { ArrowLeft, Shield, TrendingUp, Zap, Globe, BarChart3, Lock, Users, Coins, Gift, Sparkles, Trophy, Crown, Flame } from 'lucide-react';
import Logo from '../components/Logo';
import PlanCard from '../components/PlanCard';
import { PLANS } from '../lib/db';
import { useAuth } from '../lib/auth';
import GiveawayBanner from '../components/GiveawayBanner';

export default function Landing() {
  const { user } = useAuth();
  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-30 backdrop-blur-xl bg-[color:var(--color-bg)]/80 border-b border-[color:var(--color-border)] safe-top">
        <div className="max-w-7xl mx-auto px-4 sm:px-5 md:px-8 h-14 md:h-16 flex items-center justify-between gap-3">
          <Logo size={28} />
          <nav className="hidden md:flex items-center gap-7 text-sm text-[color:var(--color-ink-muted)]">
            <a href="#giveaway" className="text-[color:var(--color-gold)] font-bold hover:brightness-125 transition flex items-center gap-1.5">
              <Trophy size={14} /> سحب iPhone
            </a>
            <a href="#features" className="hover:text-[color:var(--color-gold)] transition">المميزات</a>
            <a href="#plans" className="hover:text-[color:var(--color-gold)] transition">الخطط</a>
            <a href="#how" className="hover:text-[color:var(--color-gold)] transition">كيف يعمل</a>
          </nav>
          <div className="flex items-center gap-2">
            {user ? (
              <Link to="/app" className="btn-gold px-4 md:px-5 py-2 rounded-xl text-xs md:text-sm whitespace-nowrap">لوحة التحكم</Link>
            ) : (
              <>
                <Link to="/login" className="btn-ghost px-3 md:px-4 py-2 rounded-xl text-xs md:text-sm">دخول</Link>
                <Link to="/register" className="btn-gold px-4 md:px-5 py-2 rounded-xl text-xs md:text-sm whitespace-nowrap">ابدأ الآن</Link>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative arabesque overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-20 right-[-10%] w-[500px] h-[500px] rounded-full bg-[color:var(--color-gold)]/10 blur-[120px]" />
          <div className="absolute bottom-0 left-[-10%] w-[500px] h-[500px] rounded-full bg-emerald-500/10 blur-[120px]" />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-5 md:px-8 pt-12 md:pt-20 pb-16 md:pb-24 relative">
          <div className="grid lg:grid-cols-2 gap-8 md:gap-12 items-center">
            <div className="animate-slide-up">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[color:var(--color-gold)]/10 border border-[color:var(--color-gold)]/30 text-[color:var(--color-gold)] text-xs mb-5 md:mb-6">
                <span className="w-2 h-2 rounded-full bg-[color:var(--color-gold)] pulse-glow" />
                منصة الاستثمار الذكي الرائد
              </div>
              <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.1] font-bold mb-5 md:mb-6">
                استثمِر بذكاء،
                <br />
                <span className="text-gold-gradient">اربح يومياً</span>
              </h1>
              <p className="text-base md:text-lg text-[color:var(--color-ink-muted)] mb-6 md:mb-8 leading-relaxed max-w-xl">
                منصة عربية متكاملة توفر لك خطط استثمار بعائدات يومية تتجاوز 8.5%، مع محفظة آمنة، وسحب فوري، وتتبع شفاف لكل معاملة.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link to="/register" className="btn-gold px-6 md:px-7 py-3 md:py-3.5 rounded-xl flex items-center gap-2 text-sm md:text-base">
                  أنشئ حساباً مجانياً <ArrowLeft size={18} />
                </Link>
                <a href="#plans" className="btn-ghost px-6 md:px-7 py-3 md:py-3.5 rounded-xl text-sm md:text-base">استعرض الخطط</a>
              </div>
              <div className="flex flex-wrap items-center gap-x-5 gap-y-2 mt-6 md:mt-8 text-xs md:text-sm text-[color:var(--color-ink-muted)]">
                <div className="flex items-center gap-1.5"><Shield size={14} className="text-emerald-400" /> حماية متقدمة</div>
                <div className="flex items-center gap-1.5"><Zap size={14} className="text-[color:var(--color-gold)]" /> سحب فوري</div>
                <div className="flex items-center gap-1.5"><Users size={14} className="text-sky-400" /> 120ألف+ مستثمر</div>
              </div>
            </div>

            {/* Mock dashboard preview */}
            <div className="relative float-slow max-w-md mx-auto lg:max-w-none w-full">
              <div className="card card-glow p-5 md:p-6">
                <div className="flex items-center justify-between mb-4 md:mb-5">
                  <div>
                    <div className="text-xs text-[color:var(--color-ink-muted)]">إجمالي الأرباح اليومية</div>
                    <div className="num text-3xl md:text-4xl font-extrabold text-gold-gradient">$214.75</div>
                  </div>
                  <div className="px-3 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs">▲ +6.8%</div>
                </div>
                <div className="h-32 relative mb-4">
                  <svg viewBox="0 0 300 120" className="w-full h-full">
                    <defs>
                      <linearGradient id="ar" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0" stopColor="#F5C24B" stopOpacity="0.5" />
                        <stop offset="1" stopColor="#F5C24B" stopOpacity="0" />
                      </linearGradient>
                    </defs>
                    <path d="M0,90 L30,80 L60,85 L90,65 L120,70 L150,50 L180,55 L210,35 L240,40 L270,20 L300,25 L300,120 L0,120 Z" fill="url(#ar)" />
                    <path d="M0,90 L30,80 L60,85 L90,65 L120,70 L150,50 L180,55 L210,35 L240,40 L270,20 L300,25" stroke="#F5C24B" strokeWidth="2.5" fill="none" />
                  </svg>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { l: 'المستثمر', v: '$2,450' },
                    { l: 'العائد', v: '$612.30' },
                    { l: 'الاشتراكات', v: '4' },
                  ].map(s => (
                    <div key={s.l} className="rounded-xl bg-[color:var(--color-surface)]/60 p-3">
                      <div className="text-[10px] text-[color:var(--color-ink-muted)]">{s.l}</div>
                      <div className="num font-bold">{s.v}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="absolute -bottom-6 -left-6 card p-4 hidden md:block shadow-2xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center"><Coins size={20} /></div>
                  <div>
                    <div className="text-xs text-[color:var(--color-ink-muted)]">تم منح</div>
                    <div className="num font-bold">+$21.25</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section id="stats" className="py-10 md:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-5 md:px-8 grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {[
            { v: '$24M+', l: 'أرباح موزعة' },
            { v: '120K+', l: 'مستثمر نشط' },
            { v: '99.98%', l: 'وقت تشغيل المنصة' },
            { v: '18', l: 'دولة عربية' },
          ].map((s) => (
            <div key={s.l} className="card p-4 md:p-6 text-center">
              <div className="num text-2xl sm:text-3xl md:text-4xl font-extrabold text-gold-gradient">{s.v}</div>
              <div className="text-xs md:text-sm text-[color:var(--color-ink-muted)] mt-1.5 md:mt-2">{s.l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* iPhone Giveaway Banner */}
      <GiveawayBanner />

      {/* Features */}
      <section id="features" className="py-14 md:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-5 md:px-8">
          <div className="max-w-2xl mb-8 md:mb-12">
            <div className="text-[color:var(--color-gold)] text-sm mb-2 md:mb-3">لماذا مُثمِر؟</div>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-3 md:mb-4">تجربة استثمارية <span className="text-gold-gradient">متكاملة</span></h2>
            <p className="text-sm md:text-base text-[color:var(--color-ink-muted)]">كل ما تحتاجه لإدارة استثماراتك في مكان واحد - محفظة قوية، خطط مرنة، وارتباح يومي.</p>
          </div>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4 md:gap-5">
            {[
              { icon: TrendingUp, t: 'عوائد يومية', d: 'احصل على أرباحك يومياً بنسب تصل إلى 8.5%.' },
              { icon: Coins, t: 'محفظة ذكية', d: 'إيداع وسحب سريع مع تتبع لحظي للرصيد والأرباح.' },
              { icon: Zap, t: 'جمع بنقرة', d: 'اجمع أرباحك اليومية بضغطة زر واحدة لكل الاشتراكات.' },
              { icon: Shield, t: 'حماية متقدمة', d: 'تشفير على مستوى البنوك لحماية رصيدك وبياناتك.' },
              { icon: BarChart3, t: 'تقارير شفافة', d: 'سجل كامل لكل معاملة، إيداع، أو سحب.' },
              { icon: Globe, t: 'دعم عربي كامل', d: 'واجهة عربية بالكامل ودعم على مدار الساعة.' },
            ].map((f) => (
              <div key={f.t} className="card p-6 group hover:-translate-y-1 transition-transform">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[color:var(--color-gold)]/20 to-transparent border border-[color:var(--color-gold)]/20 flex items-center justify-center text-[color:var(--color-gold)] mb-4">
                  <f.icon size={22} />
                </div>
                <div className="font-bold text-lg mb-2">{f.t}</div>
                <div className="text-sm text-[color:var(--color-ink-muted)] leading-relaxed">{f.d}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Plans */}
      <section id="plans" className="py-14 md:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-5 md:px-8">
          <div className="text-center mb-8 md:mb-12">
            <div className="text-[color:var(--color-gold)] text-sm mb-2 md:mb-3">خطط الاشتراك</div>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-3 md:mb-4">اختر خطتك <span className="text-gold-gradient">المثالية</span></h2>
            <p className="text-sm md:text-base text-[color:var(--color-ink-muted)] max-w-xl mx-auto">أربع خطط استثمارية مصممة لتلائم جميع المستويات بعائد يومي مضمون</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
            {PLANS.map(p => (
              <PlanCard key={p.id} plan={p} featured={p.id === 'gold'} />
            ))}
          </div>
          <div className="text-center mt-8 md:mt-10">
            <Link to="/register" className="btn-gold px-7 md:px-8 py-3 md:py-3.5 rounded-xl inline-flex items-center gap-2">
              ابدأ الاستثمار الآن <ArrowLeft size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="py-14 md:py-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-5 md:px-8">
          <div className="text-center mb-8 md:mb-12">
            <div className="text-[color:var(--color-gold)] text-sm mb-2 md:mb-3">كيف يعمل</div>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold">ثلاث خطوات بسيطة</h2>
          </div>
          <div className="grid sm:grid-cols-3 gap-4 md:gap-5">
            {[
              { n: '01', t: 'سجل حساباً', d: 'أنشئ حساباً مجانياً في دقيقة واحصل على مكافأة ترحيبية فورية.' },
              { n: '02', t: 'اودع واشترك', d: 'اودع في محفظتك واختر الخطة التي تلائم طموحاتك.' },
              { n: '03', t: 'اجمع أرباحك', d: 'يومياً، اضغط زر واحد لتحويل أرباحك إلى رصيدك.' },
            ].map(s => (
              <div key={s.n} className="card p-6 text-center">
                <div className="font-display text-5xl text-gold-gradient mb-3">{s.n}</div>
                <div className="font-bold text-lg mb-2">{s.t}</div>
                <div className="text-sm text-[color:var(--color-ink-muted)]">{s.d}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-14 md:py-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-5 md:px-8">
          <div className="card card-glow p-7 md:p-14 text-center relative overflow-hidden">
            <div className="absolute inset-0 pointer-events-none opacity-40">
              <div className="absolute top-0 left-0 w-72 h-72 bg-[color:var(--color-gold)]/20 blur-3xl rounded-full" />
              <div className="absolute bottom-0 right-0 w-72 h-72 bg-emerald-500/15 blur-3xl rounded-full" />
            </div>
            <div className="relative">
              <Lock className="mx-auto text-[color:var(--color-gold)] mb-3 md:mb-4" size={32} />
              <h2 className="font-display text-2xl sm:text-3xl md:text-5xl font-bold mb-3 md:mb-4 leading-tight">ابدأ رحلتك <span className="text-gold-gradient">الاستثمارية</span> اليوم</h2>
              <p className="text-sm md:text-base text-[color:var(--color-ink-muted)] mb-6 md:mb-8 max-w-xl mx-auto">انضم إلى آلاف المستثمرين الذين يحققون أرباحاً يومية مع مُثمِر.</p>
              <Link to="/register" className="btn-gold px-7 md:px-8 py-3 md:py-3.5 rounded-xl inline-flex items-center gap-2">
                أنشئ حساباً مجانياً <ArrowLeft size={18} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t border-[color:var(--color-border)] py-6 md:py-8 safe-bottom">
        <div className="max-w-7xl mx-auto px-4 sm:px-5 md:px-8 flex flex-col md:flex-row items-center justify-between gap-3 md:gap-4">
          <Logo size={28} />
          <div className="text-[11px] md:text-xs text-[color:var(--color-ink-muted)] text-center">© {new Date().getFullYear()} مُثمِر · جميع الحقوق محفوظة</div>
        </div>
      </footer>
    </div>
  );
}
