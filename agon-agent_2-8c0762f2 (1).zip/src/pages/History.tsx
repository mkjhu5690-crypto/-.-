import { useMemo, useState } from 'react';
import { ArrowDownCircle, ArrowUpCircle, Layers, Coins, Gift, Search } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { db, formatDateTimeAr, formatMoney, type TxType } from '../lib/db';

const typeMeta: Record<TxType, { label: string; Icon: any; color: string; bg: string }> = {
  deposit:   { label: 'إيداع',    Icon: ArrowDownCircle, color: 'text-emerald-300', bg: 'bg-emerald-500/10 border-emerald-500/20' },
  withdraw:  { label: 'سحب',      Icon: ArrowUpCircle,   color: 'text-rose-300',     bg: 'bg-rose-500/10 border-rose-500/20' },
  subscribe: { label: 'اشتراك',   Icon: Layers,          color: 'text-sky-300',      bg: 'bg-sky-500/10 border-sky-500/20' },
  earning:   { label: 'أرباح',    Icon: Coins,           color: 'text-[color:var(--color-gold)]', bg: 'bg-[color:var(--color-gold)]/10 border-[color:var(--color-gold)]/25' },
  bonus:     { label: 'مكافأة',    Icon: Gift,            color: 'text-fuchsia-300',  bg: 'bg-fuchsia-500/10 border-fuchsia-500/20' },
};

export default function History() {
  const { user } = useAuth();
  const [filter, setFilter] = useState<'all' | TxType>('all');
  const [q, setQ] = useState('');
  const txs = useMemo(() => user ? db.txsForUser(user.id) : [], [user]);
  if (!user) return null;

  const filtered = txs.filter(t =>
    (filter === 'all' || t.type === filter) &&
    (q.trim() === '' || t.note.toLowerCase().includes(q.toLowerCase()))
  );

  const totals = {
    deposit: sum(txs, 'deposit'),
    withdraw: Math.abs(sum(txs, 'withdraw')),
    earning: sum(txs, 'earning'),
    subscribe: Math.abs(sum(txs, 'subscribe')),
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl md:text-4xl font-bold">سجل <span className="text-gold-gradient">المعاملات</span></h1>
        <p className="text-xs md:text-sm text-[color:var(--color-ink-muted)] mt-1">تتبع كامل لأنشطة حسابك المالي</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 md:gap-3">
        <Card label="إجمالي الإيداعات" value={formatMoney(totals.deposit)} tint="emerald" />
        <Card label="إجمالي السحوبات" value={formatMoney(totals.withdraw)} tint="rose" />
        <Card label="إجمالي الأرباح" value={formatMoney(totals.earning)} tint="gold" />
        <Card label="مدفوع للاشتراكات" value={formatMoney(totals.subscribe)} tint="sky" />
      </div>

      <div className="card p-4 md:p-6">
        <div className="flex flex-col md:flex-row md:items-center gap-3 mb-5">
          <div className="relative flex-1">
            <Search size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-[color:var(--color-ink-muted)]" />
            <input className="input pr-10" placeholder="ابحث في المعاملات..." value={q} onChange={e => setQ(e.target.value)} />
          </div>
          <div className="flex flex-wrap gap-2">
            {(['all','deposit','withdraw','subscribe','earning','bonus'] as const).map(f => (
              <button key={f} onClick={() => setFilter(f)} className={`px-3 py-1.5 rounded-lg text-xs transition ${filter === f ? 'btn-gold' : 'btn-ghost'}`}>
                {f === 'all' ? 'الكل' : typeMeta[f as TxType].label}
              </button>
            ))}
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-16 text-sm text-[color:var(--color-ink-muted)]">لا توجد معاملات مطابقة</div>
        ) : (
          <div className="space-y-2">
            {filtered.map(t => {
              const m = typeMeta[t.type];
              return (
                <div key={t.id} className="flex items-center justify-between gap-3 p-4 rounded-xl bg-[color:var(--color-surface)]/50 border border-[color:var(--color-border)] hover:border-[color:var(--color-gold)]/30 transition">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${m.bg} ${m.color}`}>
                      <m.Icon size={18} />
                    </div>
                    <div className="min-w-0">
                      <div className="font-semibold text-sm truncate">{t.note}</div>
                      <div className="flex items-center gap-2 text-[11px] text-[color:var(--color-ink-muted)]">
                        <span>{formatDateTimeAr(t.createdAt)}</span>
                        <span>·</span>
                        <span>{m.label}</span>
                      </div>
                    </div>
                  </div>
                  <div className={`num font-bold ${t.amount >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>
                    {t.amount >= 0 ? '+' : ''}{formatMoney(t.amount)}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function sum(txs: any[], type: string) {
  return +txs.filter(t => t.type === type).reduce((a, t) => a + t.amount, 0).toFixed(2);
}

function Card({ label, value, tint }: { label: string; value: string; tint: 'emerald'|'rose'|'gold'|'sky' }) {
  const colors: Record<string, string> = {
    emerald: 'text-emerald-300', rose: 'text-rose-300', gold: 'text-[color:var(--color-gold)]', sky: 'text-sky-300',
  };
  return (
    <div className="card p-4">
      <div className="text-xs text-[color:var(--color-ink-muted)] mb-1">{label}</div>
      <div className={`num text-xl md:text-2xl font-extrabold ${colors[tint]}`}>{value}</div>
    </div>
  );
}
