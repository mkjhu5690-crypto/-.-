import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, ArrowLeft, Sparkles, Settings2, CheckCircle2, Send } from 'lucide-react';
import Logo from '../components/Logo';
import { useAuth } from '../lib/auth';
import { useOwner } from '../lib/owner';
import { isOwnerEmail } from '../lib/db';

type Mode = 'password' | 'magic';

export default function Login() {
  const { login, signInWithPassword, sendMagicLink, resetPassword, supabaseReady } = useAuth();
  const { loginOwner } = useOwner();
  const nav = useNavigate();
  const [mode, setMode] = useState<Mode>(supabaseReady ? 'password' : 'password');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(''); setInfo('');
    setBusy(true);
    try {
      // If the entered email belongs to the platform owner, route to the owner dashboard.
      // This is silent — regular users never see any owner-related UI.
      if (isOwnerEmail(email)) {
        const r = loginOwner(email, password);
        if (!r.ok) { setError(r.error || 'كلمة المرور غير صحيحة'); return; }
        nav('/owner');
        return;
      }

      if (supabaseReady) {
        if (mode === 'magic') {
          const r = await sendMagicLink(email);
          if (!r.ok) { setError(r.error || 'تعذر الإرسال'); return; }
          setInfo('أرسلنا رابط تسجيل الدخول إلى ' + email + ' - تحقق من بريدك');
          return;
        }
        const r = await signInWithPassword(email, password);
        if (!r.ok) { setError(r.error || 'خطأ في تسجيل الدخول'); return; }
        nav('/app');
      } else {
        const r = login(email, password);
        if (!r.ok) { setError(r.error || 'خطأ في تسجيل الدخول'); return; }
        nav('/app');
      }
    } finally { setBusy(false); }
  };

  const forgot = async () => {
    setError(''); setInfo('');
    if (!email) { setError('أدخل بريدك أولاً'); return; }
    if (!supabaseReady) { setError('إعادة تعيين كلمة المرور تتطلب تفعيل التسجيل الحقيقي'); return; }
    setBusy(true);
    const r = await resetPassword(email);
    setBusy(false);
    if (!r.ok) setError(r.error || 'خطأ'); else setInfo('تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك');
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 md:p-5 arabesque safe-top safe-bottom">
      <div className="w-full max-w-md animate-slide-up">
        <Link to="/" className="flex justify-center mb-6 md:mb-8"><Logo /></Link>

        {/* Status banner */}
        <div className={`mb-4 p-3 rounded-xl border text-xs flex items-center justify-between gap-2 ${supabaseReady ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' : 'bg-amber-500/10 border-amber-500/30 text-amber-300'}`}>
          <div className="flex items-center gap-2">
            {supabaseReady ? <CheckCircle2 size={14} /> : <Sparkles size={14} />}
            <span>{supabaseReady ? 'تسجيل دخول حقيقي مفعّل' : 'الوضع التجريبي - بيانات محلية'}</span>
          </div>
          <Link to="/setup" className="underline decoration-dotted flex items-center gap-1 hover:text-white">
            <Settings2 size={12} /> إعداد
          </Link>
        </div>

        <div className="card card-glow p-6 md:p-8">
          <h1 className="font-display text-2xl md:text-3xl font-bold mb-2">مرحباً بعودتك</h1>
          <p className="text-sm text-[color:var(--color-ink-muted)] mb-5 md:mb-6">سجل دخولك لمتابعة استثماراتك</p>

          {supabaseReady && (
            <div className="inline-flex p-1 rounded-xl bg-[color:var(--color-bg-2)] border border-[color:var(--color-border)] mb-5 text-xs">
              <button onClick={() => { setMode('password'); setError(''); setInfo(''); }} className={`px-4 py-1.5 rounded-lg transition ${mode === 'password' ? 'btn-gold' : 'text-[color:var(--color-ink-muted)]'}`}>
                بكلمة المرور
              </button>
              <button onClick={() => { setMode('magic'); setError(''); setInfo(''); }} className={`px-4 py-1.5 rounded-lg transition ${mode === 'magic' ? 'btn-gold' : 'text-[color:var(--color-ink-muted)]'}`}>
                رابط عبر البريد
              </button>
            </div>
          )}

          {error && <div className="mb-4 p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm">{error}</div>}
          {info && <div className="mb-4 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-sm">{info}</div>}

          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="text-xs text-[color:var(--color-ink-muted)] mb-1.5 block">البريد الإلكتروني</label>
              <div className="relative">
                <Mail size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-[color:var(--color-ink-muted)]" />
                <input className="input pr-10" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" required dir="ltr" />
              </div>
            </div>

            {(mode === 'password' || !supabaseReady) && (
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs text-[color:var(--color-ink-muted)]">كلمة المرور</label>
                  {supabaseReady && (
                    <button type="button" onClick={forgot} className="text-xs text-[color:var(--color-gold)] hover:underline">نسيت كلمة المرور؟</button>
                  )}
                </div>
                <div className="relative">
                  <Lock size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-[color:var(--color-ink-muted)]" />
                  <input className="input pr-10" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required dir="ltr" />
                </div>
              </div>
            )}

            {mode === 'magic' && supabaseReady && (
              <div className="p-3 rounded-lg bg-sky-500/10 border border-sky-500/25 text-xs text-sky-200 flex gap-2">
                <Send size={14} className="shrink-0 mt-0.5" />
                <span>سيصلك رابط دخول آمن على بريدك - اضغط عليه للدخول مباشرة بدون كلمة مرور.</span>
              </div>
            )}

            <button type="submit" disabled={busy} className="btn-gold w-full py-3 rounded-xl flex items-center justify-center gap-2">
              {busy ? '...' : mode === 'magic' ? <><Send size={16} /> إرسال رابط الدخول</> : <>دخول <ArrowLeft size={16} /></>}
            </button>
          </form>

          <div className="mt-6 text-center text-sm text-[color:var(--color-ink-muted)]">
            ليس لديك حساب؟ <Link to="/register" className="text-[color:var(--color-gold)] font-semibold">أنشئ حساباً</Link>
          </div>
        </div>

        <div className="text-center mt-5">
          <Link to="/" className="text-xs text-[color:var(--color-ink-muted)] hover:text-[color:var(--color-ink)]">→ العودة للرئيسية</Link>
        </div>
      </div>
    </div>
  );
}
