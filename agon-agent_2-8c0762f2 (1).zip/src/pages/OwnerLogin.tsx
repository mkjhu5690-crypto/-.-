import { Navigate } from 'react-router-dom';

// The dedicated owner-login page is no longer used — owners sign in via the
// regular /login page using their email, which is silently detected and
// routed to the owner dashboard. Keeping this as a redirect for any stale
// links or bookmarks.
export default function OwnerLogin() {
  return <Navigate to="/login" replace />;
}
