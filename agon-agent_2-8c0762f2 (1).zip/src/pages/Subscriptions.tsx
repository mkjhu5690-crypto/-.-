import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { HandCoins, Calendar, TrendingUp, Layers } from 'lucide-react';
import Toaster, { toast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import { db, formatDateAr, formatMoney } from '../lib/db';
import { claimAll, dailyEarningFor, daysPendingFor, pendingAmountFor } from '../lib/earnings';

export default function Subscriptions() {
  const { user, refresh } = useAuth();
  const [, bump] = useState(0);
  const subs = useMemo(() => user ? db.subsForUser(user.id).sort((a,b)=> +new Date(b.startDate)-+new Date(a.startDate)) : [], [user]);

  if (!user) return null;

  const onClaim = () => {
    const r = claimAll(user.id);
    if (r.amount <= 0) { toast({ kind: 'info', text: 'لا توجد أرباح جاهزة للجمع' }); return; }
    toast({ kind: 'success', text: `تم جمع ${formatMoney(r.amount)} بنجاح` });
    refresh(); bump(x => x + 1);
  };

  return (
    <div className="space-y-6">
      <Toaster />
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 md:gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl md:text-4xl font-bold">اشتراكاتي</h1>
          <p className="text-xs md:text-sm text-[color:var(--color-ink-muted)] mt-1">جميع خططك الاستثمارية في مكان واحد</p>
        </div>
        <button onClick={onClaim} className="btn-gold px-4 md:px-5 py-2.5 rounded-xl text-xs md:text-sm flex items-center justify-center gap-2 active:scale-95"><HandCoins size={16} /> جمع كل الأرباح</button>
      </div>

      {subs.length === 0 ? (
        <div className="card p-16 text-center">
          <div className="text-7xl mb-4">💰</div>
          <h3 className="font-display text-2xl font-bold mb-2">ابدأ رحلتك الاستثمارية</h3>
          <p className="text-sm text-[color:var(--color-ink-muted)] mb-6">لا توجد اشتراكات بعد - اختر خطة تناسبك</p>
          <Link to="/app/plans" className="btn-gold inline-block px-6 py-3 rounded-xl">استعرض الخطط</Link>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-3 md:gap-4">
          {subs.map(s => {
            const plan = db.getPlan(s.planId)!;
            const pending = pendingAmountFor(s);
            const days = daysPendingFor(s);
            const daily = dailyEarningFor(s);
            const active = s.status === 'active';
            const totalDays = plan.durationDays;
            const elapsed = Math.min(totalDays, Math.ceil((Date.now() - +new Date(s.startDate)) / 86400000));
            const progress = Math.min(100, (elapsed / totalDays) * 100);
            return (
              <div key={s.id} className={`card p-6 relative overflow-hidden ${!active ? 'opacity-70' : ''}`}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl bg-gradient-to-br from-[color:var(--color-gold)]/30 to-transparent border border-[color:var(--color-gold)]/30">
                      {s.planId === 'bronze' ? '🥉' : s.planId === 'silver' ? '🥈' : s.planId === 'gold' ? '🥇' : '💎'}
                    </div>
                    <div>
                      <div className="font-bold text-lg">خطة {plan.nameAr}</div>
                      <div className="text-xs text-[color:var(--color-ink-muted)]">اشتراك من {formatMoney(s.amount)}</div>
                    </div>
                  </div>
                  <div className={`text-[10px] px-2 py-1 rounded-full ${active ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30' : 'bg-slate-500/15 text-slate-300 border border-slate-500/30'}`}>
                    {active ? '• نشط' : 'منتهي'}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 mb-4">
                  <Stat icon={TrendingUp} label="يومي" value={formatMoney(daily)} />
                  <Stat icon={Layers} label="مجمع" value={formatMoney(s.totalEarned)} />
                  <Stat icon={Calendar} label="معلق" value={`${days} يوم`} />
                </div>

                {/* Progress */}
                <div className="mb-4">
                  <div className="flex justify-between text-xs text-[color:var(--color-ink-muted)] mb-1.5">
                    <span>تقدم الخطة</span>
                    <span className="num">{elapsed}/{totalDays} يوم</span>
                  </div>
                  <div className="h-2 rounded-full bg-[color:var(--color-surface-2)] overflow-hidden">
                    <div className="h-full bg-gradient-to-l from-[#F5E29B] to-[#B8860B] transition-all" style={{ width: `${progress}%` }} />
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-[color:var(--color-ink-muted)] mb-4">
                  <span>البداية: {formatDateAr(s.startDate)}</span>
                  <span>النهاية: {formatDateAr(s.endDate)}</span>
                </div>

                {active && (
                  <div className="p-3 rounded-xl bg-gradient-to-l from-[color:var(--color-gold)]/15 to-transparent border border-[color:var(--color-gold)]/25 flex items-center justify-between">
                    <div>
                      <div className="text-[11px] text-[color:var(--color-ink-muted)]">جاهز للجمع</div>
                      <div className="num text-xl font-bold text-[color:var(--color-gold)]">{formatMoney(pending)}</div>
                    </div>
                    <button onClick={onClaim} disabled={pending<=0} className="btn-gold px-4 py-2 rounded-lg text-sm flex items-center gap-1">
                      <HandCoins size={14} /> جمع
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Stat({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div className="p-2.5 rounded-lg bg-[color:var(--color-surface)]/50 border border-[color:var(--color-border)]">
      <div className="flex items-center gap-1 text-[color:var(--color-ink-muted)] text-[10px] mb-1"><Icon size={11} /> {label}</div>
      <div className="num font-bold text-sm">{value}</div>
    </div>
  );
}
