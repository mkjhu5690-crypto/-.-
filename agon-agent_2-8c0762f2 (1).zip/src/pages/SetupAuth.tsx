import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Database, ExternalLink, CheckCircle2, AlertCircle, KeyRound, Globe } from 'lucide-react';
import Logo from '../components/Logo';
import { saveSupabaseConfig, clearSupabaseConfig, getSupabaseConfig } from '../lib/supabase';

export default function SetupAuth() {
  const nav = useNavigate();
  const existing = getSupabaseConfig();
  const [url, setUrl] = useState(existing?.url || '');
  const [key, setKey] = useState(existing?.anonKey || '');
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const cleanUrl = url.trim().replace(/\/$/, '');
    const cleanKey = key.trim();
    if (!cleanUrl.startsWith('https://') || !cleanUrl.includes('.supabase.co')) {
      setError('رابط Supabase غير صالح - مثال: https://xxx.supabase.co');
      return;
    }
    if (cleanKey.length < 40) {
      setError('مفتاح anon غير صالح');
      return;
    }
    saveSupabaseConfig({ url: cleanUrl, anonKey: cleanKey });
    setSaved(true);
    setTimeout(() => nav('/login'), 900);
  };

  const reset = () => {
    clearSupabaseConfig();
    setUrl(''); setKey(''); setSaved(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-5 arabesque">
      <div className="w-full max-w-2xl">
        <Link to="/" className="flex justify-center mb-8"><Logo /></Link>

        <div className="card card-glow p-8">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 flex items-center justify-center">
              <Database size={22} />
            </div>
            <div>
              <h1 className="font-display text-2xl md:text-3xl font-bold">تفعيل التسجيل الحقيقي</h1>
              <p className="text-sm text-[color:var(--color-ink-muted)]">اربط Supabase لتفعيل البريد الحقيقي والمصادقة</p>
            </div>
          </div>

          <div className="mb-6 p-4 rounded-xl bg-[color:var(--color-surface)]/50 border border-[color:var(--color-border)] text-sm space-y-3">
            <div className="font-bold text-[color:var(--color-gold)]">خطوات سريعة (دقيقتان):</div>
            <ol className="space-y-2 text-[color:var(--color-ink-muted)] list-decimal pr-5">
              <li>
                اذهب إلى
                <a href="https://supabase.com/dashboard" target="_blank" rel="noreferrer" className="text-[color:var(--color-gold)] mx-1 inline-flex items-center gap-1">
                  supabase.com/dashboard <ExternalLink size={12} />
                </a>
                وأنشئ مشروعاً جديداً مجاناً
              </li>
              <li>من القائمة الجانبية اختر <b className="text-[color:var(--color-ink)]">Project Settings → API</b></li>
              <li>انسخ <b className="text-[color:var(--color-ink)]">Project URL</b> و <b className="text-[color:var(--color-ink)]">anon public key</b></li>
              <li>الصقهما هنا بالأسفل واحفظ</li>
              <li>(اختياري) في <b>Authentication → URL Configuration</b> أضف رابط موقعك إلى Redirect URLs</li>
            </ol>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm flex items-center gap-2">
              <AlertCircle size={16} /> {error}
            </div>
          )}
          {saved && (
            <div className="mb-4 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-sm flex items-center gap-2">
              <CheckCircle2 size={16} /> تم الحفظ - جاري التحويل...
            </div>
          )}

          <form onSubmit={save} className="space-y-4">
            <div>
              <label className="text-xs text-[color:var(--color-ink-muted)] mb-1.5 block">Project URL</label>
              <div className="relative">
                <Globe size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-[color:var(--color-ink-muted)]" />
                <input className="input pr-10" value={url} onChange={e => setUrl(e.target.value)} placeholder="https://xxxxx.supabase.co" dir="ltr" required />
              </div>
            </div>
            <div>
              <label className="text-xs text-[color:var(--color-ink-muted)] mb-1.5 block">Anon Public Key</label>
              <div className="relative">
                <KeyRound size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-[color:var(--color-ink-muted)]" />
                <input className="input pr-10 font-mono text-xs" value={key} onChange={e => setKey(e.target.value)} placeholder="eyJhbGci..." dir="ltr" required />
              </div>
              <p className="text-[11px] text-[color:var(--color-ink-muted)] mt-1.5">آمن للاستخدام في المتصفح - المفتاح العام فقط. لا تستخدم service_role هنا.</p>
            </div>

            <div className="flex gap-2 pt-2">
              <button type="submit" className="btn-gold flex-1 py-3 rounded-xl">حفظ وتفعيل</button>
              {existing && (
                <button type="button" onClick={reset} className="btn-ghost px-5 py-3 rounded-xl">إعادة تعيين</button>
              )}
            </div>
          </form>

          <div className="mt-6 pt-6 border-t border-[color:var(--color-border)]">
            <div className="text-sm text-[color:var(--color-ink-muted)] mb-2">لا تريد الإعداد الآن؟</div>
            <Link to="/login" className="text-[color:var(--color-gold)] text-sm font-semibold">→ استخدم الوضع التجريبي (بيانات محلية)</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
