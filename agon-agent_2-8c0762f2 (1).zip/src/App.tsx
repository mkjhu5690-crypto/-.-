import { Routes, Route, Navigate } from 'react-router-dom';
import Landing from './pages/Landing';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Wallet from './pages/Wallet';
import Plans from './pages/Plans';
import History from './pages/History';
import Subscriptions from './pages/Subscriptions';
import SetupAuth from './pages/SetupAuth';
import OwnerLogin from './pages/OwnerLogin';
import OwnerDashboard from './pages/OwnerDashboard';
import AppShell from './components/AppShell';
import { useAuth } from './lib/auth';
import { useOwner } from './lib/owner';

function Protected({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;
  return <AppShell>{children}</AppShell>;
}

function OwnerProtected({ children }: { children: React.ReactNode }) {
  const { isOwner } = useOwner();
  if (!isOwner) return <Navigate to="/owner/login" replace />;
  return <>{children}</>;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/setup" element={<SetupAuth />} />
      <Route path="/app" element={<Protected><Dashboard /></Protected>} />
      <Route path="/app/wallet" element={<Protected><Wallet /></Protected>} />
      <Route path="/app/plans" element={<Protected><Plans /></Protected>} />
      <Route path="/app/subscriptions" element={<Protected><Subscriptions /></Protected>} />
      <Route path="/app/history" element={<Protected><History /></Protected>} />
      <Route path="/owner/login" element={<OwnerLogin />} />
      <Route path="/owner" element={<OwnerProtected><OwnerDashboard /></OwnerProtected>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
