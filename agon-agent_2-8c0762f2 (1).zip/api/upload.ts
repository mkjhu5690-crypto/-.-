// Uploads proof images to a dedicated JSONBlob and returns the blob URL.
// Using separate blobs for images keeps the main data blob small and fast.

import type { VercelRequest, VercelResponse } from '@vercel/node';

function setCors(res: VercelResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'method not allowed' });

  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    const { dataUrl, name } = body || {};
    if (!dataUrl || typeof dataUrl !== 'string' || !dataUrl.startsWith('data:')) {
      return res.status(400).json({ error: 'invalid dataUrl' });
    }
    // Limit to ~4MB base64
    if (dataUrl.length > 5_500_000) {
      return res.status(413).json({ error: 'image too large' });
    }

    const r = await fetch('https://jsonblob.com/api/jsonBlob', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ dataUrl, name: name || 'proof', uploadedAt: new Date().toISOString() }),
    });
    if (!r.ok) return res.status(502).json({ error: 'upload failed' });
    const location = r.headers.get('x-jsonblob-id') || r.headers.get('location') || '';
    const id = location.replace(/.*\//, '');
    if (!id) return res.status(502).json({ error: 'no blob id' });
    return res.status(200).json({ id, url: `/api/proof?id=${id}` });
  } catch (e: any) {
    return res.status(500).json({ error: e?.message || 'server error' });
  }
}

export const config = {
  api: {
    bodyParser: { sizeLimit: '6mb' },
  },
};
