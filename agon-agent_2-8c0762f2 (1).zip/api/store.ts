// Vercel Serverless Function - acts as a proxy to JSONBlob for shared storage.
// This allows all devices (users + owner) to share the same database.

import type { VercelRequest, VercelResponse } from '@vercel/node';

// Main data blob for the platform (users, subscriptions, transactions, requests)
const BLOB_ID = process.env.JSONBLOB_ID || '019da585-a75d-7cad-abe8-893c90158869';
const BLOB_URL = `https://jsonblob.com/api/jsonBlob/${BLOB_ID}`;

interface DataStore {
  version: number;
  users: any[];
  subscriptions: any[];
  transactions: any[];
  requests: any[];
}

const EMPTY: DataStore = { version: 1, users: [], subscriptions: [], transactions: [], requests: [] };

async function readStore(): Promise<DataStore> {
  try {
    const r = await fetch(BLOB_URL, { headers: { 'Accept': 'application/json' } });
    if (!r.ok) return { ...EMPTY };
    const data = await r.json();
    return {
      version: data.version ?? 1,
      users: Array.isArray(data.users) ? data.users : [],
      subscriptions: Array.isArray(data.subscriptions) ? data.subscriptions : [],
      transactions: Array.isArray(data.transactions) ? data.transactions : [],
      requests: Array.isArray(data.requests) ? data.requests : [],
    };
  } catch {
    return { ...EMPTY };
  }
}

async function writeStore(data: DataStore): Promise<boolean> {
  try {
    const r = await fetch(BLOB_URL, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return r.ok;
  } catch {
    return false;
  }
}

function setCors(res: VercelResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(200).end();

  try {
    if (req.method === 'GET') {
      const data = await readStore();
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const { action, payload } = body || {};

      const store = await readStore();

      if (action === 'upsertUser') {
        const u = payload;
        const idx = store.users.findIndex((x: any) => x.id === u.id);
        if (idx >= 0) store.users[idx] = u; else store.users.push(u);
      }
      else if (action === 'upsertSub') {
        const s = payload;
        const idx = store.subscriptions.findIndex((x: any) => x.id === s.id);
        if (idx >= 0) store.subscriptions[idx] = s; else store.subscriptions.push(s);
      }
      else if (action === 'addTx') {
        store.transactions.push(payload);
      }
      else if (action === 'addRequest') {
        store.requests.push(payload);
      }
      else if (action === 'updateRequest') {
        const idx = store.requests.findIndex((x: any) => x.id === payload.id);
        if (idx >= 0) store.requests[idx] = payload;
      }
      else if (action === 'replaceAll') {
        // Bulk overwrite (used by sync-push)
        Object.assign(store, payload);
      }
      else {
        return res.status(400).json({ error: 'unknown action' });
      }

      const ok = await writeStore(store);
      if (!ok) return res.status(502).json({ error: 'write failed' });
      return res.status(200).json({ ok: true, store });
    }

    return res.status(405).json({ error: 'method not allowed' });
  } catch (e: any) {
    return res.status(500).json({ error: e?.message || 'server error' });
  }
}

export const config = {
  api: {
    bodyParser: { sizeLimit: '10mb' }, // allow embedded proof images
  },
};
