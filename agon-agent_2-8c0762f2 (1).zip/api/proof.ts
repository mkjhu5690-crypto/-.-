// Returns a proof image (from JSONBlob) by id.
// Proxies through our API to bypass CORS in the browser.

import type { VercelRequest, VercelResponse } from '@vercel/node';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  const { id } = req.query;
  if (!id || typeof id !== 'string') return res.status(400).json({ error: 'id required' });
  try {
    const r = await fetch(`https://jsonblob.com/api/jsonBlob/${encodeURIComponent(id)}`);
    if (!r.ok) return res.status(404).json({ error: 'not found' });
    const data = await r.json();
    if (!data?.dataUrl) return res.status(404).json({ error: 'no image' });
    return res.status(200).json({ dataUrl: data.dataUrl, name: data.name });
  } catch (e: any) {
    return res.status(500).json({ error: e?.message || 'server error' });
  }
}
